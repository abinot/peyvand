<?php
if (!function_exists('_1b729ad1a5d74eaed342d419d10c9d8d')):
function _1b729ad1a5d74eaed342d419d10c9d8d($__blaze, $__data = [], $__slots = [], $__bound = [], $__keys = [], $__this = null) {
$__env = $__blaze->env;
$__slots['slot'] ??= new \Illuminate\View\ComponentSlot('');
if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP);
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::make($__data, $__bound, $__keys);
unset($__data, $__bound, $__keys);
ob_start();
?>


<?php
extract(Flux::forwardedAttributes($attributes, [
    'tooltipPosition',
    'tooltipKbd',
    'tooltip',
]));
?>

<?php $tooltipPosition = $tooltipPosition ??= $attributes->pluck('tooltip:position'); ?>
<?php $tooltipKbd = $tooltipKbd ??= $attributes->pluck('tooltip:kbd'); ?>
<?php $tooltip = $tooltip ??= $attributes->pluck('tooltip'); ?>

<?php
$__defaults = [
    'tooltipPosition' => 'top',
    'tooltipKbd' => null,
    'tooltip' => null,
];
$tooltipPosition ??= $attributes['tooltip-position'] ?? $attributes['tooltipPosition'] ?? $__defaults['tooltipPosition']; unset($attributes['tooltipPosition'], $attributes['tooltip-position']);
$tooltipKbd ??= $attributes['tooltip-kbd'] ?? $attributes['tooltipKbd'] ?? $__defaults['tooltipKbd']; unset($attributes['tooltipKbd'], $attributes['tooltip-kbd']);
$tooltip ??= $attributes['tooltip'] ?? $__defaults['tooltip']; unset($attributes['tooltip']);
unset($__defaults);
?>

<?php if ($tooltip): ?>
    <?php if (!function_exists('_d6269858c680fb9b6b96e01ddfbee798')) { $__blaze->compile('/home3/myrwqtei/AbinotPeyvand/vendor/livewire/flux/src/../stubs/resources/views/flux/tooltip/index.blade.php', $__blaze->compiledPath.'/d6269858c680fb9b6b96e01ddfbee798.php'); require $__blaze->compiledPath.'/d6269858c680fb9b6b96e01ddfbee798.php'; } ?>
<?php if (isset($__slotsd6269858c680fb9b6b96e01ddfbee798)) { $__slotsStackd6269858c680fb9b6b96e01ddfbee798[] = $__slotsd6269858c680fb9b6b96e01ddfbee798; } ?>
<?php if (isset($__attrsd6269858c680fb9b6b96e01ddfbee798)) { $__attrsStackd6269858c680fb9b6b96e01ddfbee798[] = $__attrsd6269858c680fb9b6b96e01ddfbee798; } ?>
<?php $__attrsd6269858c680fb9b6b96e01ddfbee798 = ['class' => 'inline-flex','content' => $tooltip,'position' => $tooltipPosition,'kbd' => $tooltipKbd]; ?>
<?php $__slotsd6269858c680fb9b6b96e01ddfbee798 = []; ?>
<?php $__blaze->pushData($__attrsd6269858c680fb9b6b96e01ddfbee798); ?>
<?php ob_start(); ?>
        <?php echo e($slot); ?>

    <?php $__slotsd6269858c680fb9b6b96e01ddfbee798['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsd6269858c680fb9b6b96e01ddfbee798); ?>
<?php _d6269858c680fb9b6b96e01ddfbee798($__blaze, $__attrsd6269858c680fb9b6b96e01ddfbee798, $__slotsd6269858c680fb9b6b96e01ddfbee798, ['content', 'position', 'kbd'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackd6269858c680fb9b6b96e01ddfbee798)) { $__slotsd6269858c680fb9b6b96e01ddfbee798 = array_pop($__slotsStackd6269858c680fb9b6b96e01ddfbee798); } ?>
<?php if (! empty($__attrsStackd6269858c680fb9b6b96e01ddfbee798)) { $__attrsd6269858c680fb9b6b96e01ddfbee798 = array_pop($__attrsStackd6269858c680fb9b6b96e01ddfbee798); } ?>
<?php $__blaze->popData(); ?>
<?php else: ?>
    <?php echo e($slot); ?>

<?php endif; ?>
<?php
echo ltrim(ob_get_clean());
} endif; ?><?php /**PATH /home3/myrwqtei/AbinotPeyvand/vendor/livewire/flux/src/../stubs/resources/views/flux/with-tooltip.blade.php ENDPATH**/ ?>