<?php # [BlazeFolded]:{flux::heading}:{/home3/myrwqtei/AbinotPeyvand/vendor/livewire/flux/src/../stubs/resources/views/flux/heading.blade.php}:{1790619292} ?>
<?php # [BlazeFolded]:{flux::subheading}:{/home3/myrwqtei/AbinotPeyvand/vendor/livewire/flux/src/../stubs/resources/views/flux/subheading.blade.php}:{1790619292} ?>
<?php # [BlazeFolded]:{flux::separator}:{/home3/myrwqtei/AbinotPeyvand/vendor/livewire/flux/src/../stubs/resources/views/flux/separator.blade.php}:{1790619292} ?>
<div class="relative mb-6 w-full">
    <?php ob_start(); ?><h1 class="font-medium [:where(&amp;)]:text-zinc-800 [:where(&amp;)]:dark:text-white text-2xl [&amp;:has(+[data-flux-subheading])]:mb-2 [[data-flux-subheading]+&amp;]:mt-2" data-flux-heading><?php ob_start(); ?><?php echo e(__('Settings')); ?><?php echo trim(ob_get_clean()); ?></h1>

        <?php echo ltrim(ob_get_clean()); ?>
    <?php ob_start(); ?><div class="text-base [:where(&amp;)]:text-zinc-500 [:where(&amp;)]:dark:text-white/70 mb-6" data-flux-subheading>
    <?php ob_start(); ?><?php echo e(__('Manage your profile and account settings')); ?><?php echo trim(ob_get_clean()); ?>

</div>
<?php echo ltrim(ob_get_clean()); ?>
    <?php ob_start(); ?><div data-orientation="horizontal" role="none" class="border-0 [print-color-adjust:exact] bg-zinc-800/5 dark:bg-white/10 h-px w-full" data-flux-separator></div>
<?php echo ltrim(ob_get_clean()); ?>
</div>
<?php /**PATH /home3/myrwqtei/AbinotPeyvand/resources/views/partials/settings-heading.blade.php ENDPATH**/ ?>