<?php

use Livewire\Component;

return new class extends Component {
    protected function view($data = [])
    {
        return app('view')->file('/home3/myrwqtei/AbinotPeyvand/storage/framework/views/livewire/views/97d3627f.blade.php', $data);
    }
}; 