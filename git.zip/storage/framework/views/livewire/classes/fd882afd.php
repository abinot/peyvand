<?php

use App\Models\Link;
use App\Models\LinkClick;
use App\Models\Team;
use Illuminate\Support\Facades\DB;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Livewire\Component;

return new #[Layout('layouts::app')] #[Title('آمار پیوندها')] class extends Component
{
    private function currentTeam(): Team
    {
        $user = auth()->user();
        $team = $user?->currentTeam;

        abort_unless(
            $user && $team && $user->belongsToTeam($team),
            403
        );

        return $team;
    }

    #[Computed]
    public function team(): Team
    {
        return $this->currentTeam();
    }

    #[Computed]
    public function report(): array
    {
        $teamId = (int) $this->currentTeam()->id;
        $now = now();

        /*
        |--------------------------------------------------------------------------
        | Team clicks
        |--------------------------------------------------------------------------
        */

        $teamClicks = LinkClick::query()
            ->whereHas('link', fn ($query) => $query
                ->where('team_id', $teamId)
            );

        $totalClicks = (clone $teamClicks)->count();

        $clicks24h = (clone $teamClicks)
            ->where('created_at', '>=', $now->copy()->subDay())
            ->count();

        $uniqueVisitors = (clone $teamClicks)
            ->whereNotNull('ip_hash')
            ->distinct()
            ->count('ip_hash');

        /*
        |--------------------------------------------------------------------------
        | Recent clicks
        |--------------------------------------------------------------------------
        */

        $clicks = (clone $teamClicks)
            ->with('link:id,code,title')
            ->latest('created_at')
            ->limit(5000)
            ->get();

        /*
        |--------------------------------------------------------------------------
        | Daily statistics
        |--------------------------------------------------------------------------
        */

        $startDate = $now->copy()->subDays(13)->startOfDay();

        $dailyRows = (clone $teamClicks)
            ->where('link_clicks.created_at', '>=', $startDate)
            ->selectRaw('DATE(link_clicks.created_at) as day, COUNT(*) as clicks')
            ->groupBy(DB::raw('DATE(link_clicks.created_at)'))
            ->orderBy('day')
            ->get()
            ->keyBy('day');

        $daily = collect(range(13, 0))
            ->map(function (int $daysAgo) use ($dailyRows, $now) {
                $date = $now->copy()->subDays($daysAgo);
                $dayKey = $date->toDateString();

                return [
                    'day' => $dayKey,
                    'label' => $date->format('m/d'),
                    'clicks' => (int) (
                        $dailyRows->get($dayKey)?->clicks ?? 0
                    ),
                ];
            })
            ->values();

        /*
        |--------------------------------------------------------------------------
        | Grouped chart: clicks per link per day
        |--------------------------------------------------------------------------
        */

        $chartLinks = Link::query()
            ->forTeam($teamId)
            ->withCount([
                'clickLogs as recent_clicks_count' => fn ($query) => $query
                    ->where('created_at', '>=', $startDate),
            ])
            ->orderByDesc('recent_clicks_count')
            ->limit(8)
            ->get()
            ->filter(fn ($link) => (int) $link->recent_clicks_count > 0)
            ->values();

        $chartLinkIds = $chartLinks->pluck('id');

        $dailyLinkRows = $chartLinkIds->isEmpty()
            ? collect()
            : LinkClick::query()
                ->whereIn('link_id', $chartLinkIds)
                ->where('created_at', '>=', $startDate)
                ->selectRaw(
                    'link_id, DATE(created_at) as day, COUNT(*) as clicks'
                )
                ->groupBy('link_id', DB::raw('DATE(created_at)'))
                ->get();

        $chartColors = [
            '#3B82F6',
            '#10B981',
            '#F59E0B',
            '#EF4444',
            '#8B5CF6',
            '#06B6D4',
            '#F97316',
            '#EC4899',
        ];

        $datasets = $chartLinks
            ->values()
            ->map(function ($link, $index) use (
                $dailyLinkRows,
                $daily,
                $chartColors
            ) {
                $rows = $dailyLinkRows
                    ->where('link_id', $link->id)
                    ->keyBy('day');

                $color = $chartColors[$index % count($chartColors)];

                return [
                    'label' => $link->title ?: '/'.$link->code,

                    'data' => $daily
                        ->map(fn ($day) => (int) (
                            $rows->get($day['day'])?->clicks ?? 0
                        ))
                        ->values()
                        ->all(),

                    'backgroundColor' => $color,
                    'borderColor' => $color,
                    'borderWidth' => 1,
                    'borderRadius' => 4,
                ];
            })
            ->values()
            ->all();

        $chart = [
            'labels' => $daily->pluck('label')->values()->all(),
            'datasets' => $datasets,
        ];

        /*
        |--------------------------------------------------------------------------
        | Top links
        |--------------------------------------------------------------------------
        */

        $topLinks = Link::query()
            ->forTeam($teamId)
            ->withCount('clickLogs')
            ->orderByDesc('click_logs_count')
            ->limit(10)
            ->get();

        /*
        |--------------------------------------------------------------------------
        | Grouped statistics
        |--------------------------------------------------------------------------
        */

        $groupCounts = static function ($values) {
            return collect($values)
                ->map(fn ($value) => filled($value)
                    ? trim((string) $value)
                    : 'نامشخص'
                )
                ->countBy()
                ->sortDesc()
                ->take(8)
                ->map(fn ($count, $name) => [
                    'name' => $name,
                    'count' => $count,
                ])
                ->values();
        };

        $utmSources = $groupCounts(
            $clicks->map(
                fn ($click) => data_get(
                    $click->utm_parameters,
                    'utm_source'
                ) ?: 'بدون UTM'
            )
        );

        $devices = $groupCounts(
            $clicks->pluck('device_type')
        );

        $browsers = $groupCounts(
            $clicks->pluck('browser')
        );

        $referrers = $groupCounts(
            $clicks->map(function ($click) {
                $host = $click->referer
                    ? parse_url($click->referer, PHP_URL_HOST)
                    : null;

                return $host ?: 'ورود مستقیم / نامشخص';
            })
        );

        /*
        |--------------------------------------------------------------------------
        | Return report
        |--------------------------------------------------------------------------
        */

        return [
            'links' => Link::forTeam($teamId)->count(),

            'clicks' => $totalClicks,

            'clicks_24h' => $clicks24h,

            'unique_visitors' => $uniqueVisitors,

            'daily' => $daily,

            'chart' => $chart,

            'top_links' => $topLinks,

            'utm_sources' => $utmSources,

            'devices' => $devices,

            'browsers' => $browsers,

            'referrers' => $referrers,

            'sample_size' => $clicks->count(),
        ];
    }

    protected function view($data = [])
    {
        return app('view')->file('/home3/myrwqtei/AbinotPeyvand/storage/framework/views/livewire/views/fd882afd.blade.php', $data);
    }
};
