<?php

use App\Models\Link;
use App\Models\LinkClick;
use App\Models\Team;
use Illuminate\Validation\Rule;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Locked;
use Livewire\Attributes\Title;
use Livewire\Component;
use Livewire\WithPagination;

return new #[Layout('layouts::app')] #[Title('مدیریت پیوندها')] class extends Component
{
    use WithPagination;

    public string $url = '';
    public string $title = '';
    public string $customCode = '';
    public ?string $expiresAt = null;
    public ?int $folderId = null;
    public ?int $categoryId = null;
    public array $tagIds = [];
    public array $metadataRows = [];
    public array $editMetadataRows = [];
    #[Locked]
    public array $editExtraTrackingRules = [];
    public string $utmSource = '';
    public string $utmMedium = '';
    public string $utmCampaign = '';
    public string $utmTerm = '';
    public string $utmContent = '';


    public string $search = '';
    public ?int $filterFolderId = null;
    public ?int $filterCategoryId = null;
    public ?int $filterTagId = null;

    public ?int $editingLinkId = null;
    public string $editingCode = '';
    public string $editUrl = '';
    public string $editTitle = '';
    public ?string $editExpiresAt = null;
    public ?int $editFolderId = null;
    public ?int $editCategoryId = null;
    public array $editTagIds = [];
    public string $editUtmSource = '';
    public string $editUtmMedium = '';
    public string $editUtmCampaign = '';
    public string $editUtmTerm = '';
    public string $editUtmContent = '';
    public bool $showEditModal = false;

    private function currentTeam(): Team
    {
        $user = auth()->user();
        $team = $user?->currentTeam;

        abort_unless($user && $team && $user->belongsToTeam($team), 403);

        return $team;
    }

    private function currentTeamId(): int
    {
        return (int) $this->currentTeam()->id;
    }

    private function teamLink(int $id): Link
    {
        return Link::query()
            ->forTeam($this->currentTeamId())
            ->findOrFail($id);
    }

    protected function rules(): array
    {
        $teamId = $this->currentTeamId();

        return [
            'url' => ['required', 'url:http,https', 'max:2048'],
            'title' => ['nullable', 'string', 'max:255'],
            'customCode' => [
                'nullable', 'alpha_dash:ascii', 'min:3', 'max:32',
                Rule::unique('links', 'code'),
                function (string $attribute, mixed $value, Closure $fail): void {
                    if (is_string($value) && in_array(strtolower($value), Link::RESERVED, true)) {
                        $fail('این کد برای مسیرهای داخلی سامانه رزرو شده است.');
                    }
                },
            ],
            'expiresAt' => ['nullable', 'date', 'after:now'],
            'folderId' => ['nullable', 'integer', Rule::exists('link_folders', 'id')->where('team_id', $teamId)],
            'categoryId' => ['nullable', 'integer', Rule::exists('link_categories', 'id')->where('team_id', $teamId)],
            'tagIds' => ['array', 'max:30'],
            'tagIds.*' => ['integer', Rule::exists('link_tags', 'id')->where('team_id', $teamId)],
            'metadataRows' => ['array', 'max:50'],
            'metadataRows.*.key' => ['nullable', 'string', 'max:100'],
            'metadataRows.*.value' => ['nullable', 'string', 'max:2000'],
            'metadataRows.*.mode' => ['nullable', 'in:store,get,utm'],
            'metadataRows.*.parameter' => ['nullable', 'string', 'max:100'],
            'utmSource' => ['nullable', 'string', 'max:255'],
            'utmMedium' => ['nullable', 'string', 'max:255'],
            'utmCampaign' => ['nullable', 'string', 'max:255'],
            'utmTerm' => ['nullable', 'string', 'max:255'],
            'utmContent' => ['nullable', 'string', 'max:255'],
        ];
    }

    private function editRules(): array
    {
        $teamId = $this->currentTeamId();

        return [
            'editUrl' => ['required', 'url:http,https', 'max:2048'],
            'editTitle' => ['nullable', 'string', 'max:255'],
            'editExpiresAt' => ['nullable', 'date'],
            'editFolderId' => ['nullable', 'integer', Rule::exists('link_folders', 'id')->where('team_id', $teamId)],
            'editCategoryId' => ['nullable', 'integer', Rule::exists('link_categories', 'id')->where('team_id', $teamId)],
            'editTagIds' => ['array', 'max:30'],
            'editTagIds.*' => ['integer', Rule::exists('link_tags', 'id')->where('team_id', $teamId)],
            'editMetadataRows' => ['array', 'max:50'],
            'editMetadataRows.*.key' => ['nullable', 'string', 'max:100'],
            'editMetadataRows.*.value' => ['nullable', 'string', 'max:2000'],
            'editMetadataRows.*.mode' => ['nullable', 'in:store,get,utm'],
            'editMetadataRows.*.parameter' => ['nullable', 'string', 'max:100'],
            'editUtmSource' => ['nullable', 'string', 'max:255'],
            'editUtmMedium' => ['nullable', 'string', 'max:255'],
            'editUtmCampaign' => ['nullable', 'string', 'max:255'],
            'editUtmTerm' => ['nullable', 'string', 'max:255'],
            'editUtmContent' => ['nullable', 'string', 'max:255'],
        ];
    }

    public function updatedSearch(): void
    {
        $this->resetPage();
    }

    public function updatedFilterFolderId(): void
    {
        $this->resetPage();
    }

    public function updatedFilterCategoryId(): void
    {
        $this->resetPage();
    }

    public function updatedFilterTagId(): void
    {
        $this->resetPage();
    }

    public function create(): void
    {
        $data = $this->validate();

        if ($this->isOwnDomain($data['url'])) {
            $this->addError('url', 'نمی‌توانید نشانی همین سایت را کوتاه کنید.');
            return;
        }

        $metadataAndRules = $this->metadataAndRules($data['metadataRows'] ?? [], 'metadataRows');
        if ($metadataAndRules === null) {
            return;
        }
        $metadata = $metadataAndRules['metadata'];

        $metadata['utm_defaults'] = $this->utmDefaults([
            'utm_source' => $data['utmSource'] ?? '',
            'utm_medium' => $data['utmMedium'] ?? '',
            'utm_campaign' => $data['utmCampaign'] ?? '',
            'utm_term' => $data['utmTerm'] ?? '',
            'utm_content' => $data['utmContent'] ?? '',
        ]);
        if ($metadata['utm_defaults'] === []) {
            unset($metadata['utm_defaults']);
        }

        $user = auth()->user();
        $link = Link::create([
            'team_id' => $this->currentTeamId(),
            'created_by' => $user->id,
            'folder_id' => $data['folderId'] ?? null,
            'category_id' => $data['categoryId'] ?? null,
            'code' => $data['customCode'] ?: Link::generateCode(),
            'original_url' => $data['url'],
            'title' => $data['title'] ?: null,
            'expires_at' => $data['expiresAt'] ?: null,
            'metadata' => $metadata ?: null,
            'tracking_rules' => $metadataAndRules['tracking_rules'] ?: null,
        ]);

        $link->tags()->sync(array_map('intval', $data['tagIds'] ?? []));

        $this->reset(
            'url', 'title', 'customCode', 'expiresAt', 'folderId', 'categoryId',
            'tagIds', 'utmSource', 'utmMedium', 'utmCampaign', 'utmTerm', 'utmContent', 'metadataRows',
        );
        $this->metadataRows = [];
        $this->resetPage();
        $this->refreshLists();
        $this->dispatch('link-created');
    }

    public function edit(int $id): void
    {
        $link = $this->teamLink($id)->load(['folder', 'category', 'tags']);
        $metadata = $link->metadata ?? [];
        $utm = $metadata['utm_defaults'] ?? [];
        unset($metadata['utm_defaults']);

        $this->editingLinkId = $link->id;
        $this->editingCode = $link->code;
        $this->editUrl = $link->original_url;
        $this->editTitle = $link->title ?? '';
        $this->editExpiresAt = $link->expires_at?->format('Y-m-d\TH:i');
        $this->editFolderId = $link->folder_id;
        $this->editCategoryId = $link->category_id;
        $this->editTagIds = $link->tags->pluck('id')->map(fn ($id) => (string) $id)->all();
        $this->editMetadataRows = $this->metadataRowsForEditor($metadata, $link->tracking_rules ?? []);
        $this->editExtraTrackingRules = $this->complexTrackingRules($link->tracking_rules ?? [], $metadata);
        $this->editUtmSource = $utm['utm_source'] ?? '';
        $this->editUtmMedium = $utm['utm_medium'] ?? '';
        $this->editUtmCampaign = $utm['utm_campaign'] ?? '';
        $this->editUtmTerm = $utm['utm_term'] ?? '';
        $this->editUtmContent = $utm['utm_content'] ?? '';
        $this->showEditModal = true;
    }

    public function saveEdit(): void
    {
        $link = $this->teamLink((int) $this->editingLinkId);
        $data = $this->validate($this->editRules());

        if ($this->isOwnDomain($data['editUrl'])) {
            $this->addError('editUrl', 'نمی‌توانید نشانی همین سایت را به‌عنوان مقصد انتخاب کنید.');
            return;
        }

        $metadataAndRules = $this->metadataAndRules($data['editMetadataRows'] ?? [], 'editMetadataRows');
        if ($metadataAndRules === null) {
            return;
        }
        $metadata = $metadataAndRules['metadata'];

        $metadata['utm_defaults'] = $this->utmDefaults([
            'utm_source' => $data['editUtmSource'] ?? '',
            'utm_medium' => $data['editUtmMedium'] ?? '',
            'utm_campaign' => $data['editUtmCampaign'] ?? '',
            'utm_term' => $data['editUtmTerm'] ?? '',
            'utm_content' => $data['editUtmContent'] ?? '',
        ]);
        if ($metadata['utm_defaults'] === []) {
            unset($metadata['utm_defaults']);
        }

        $trackingRules = array_replace_recursive($this->editExtraTrackingRules, $metadataAndRules['tracking_rules']);
        $link->update([
            'folder_id' => $data['editFolderId'] ?? null,
            'category_id' => $data['editCategoryId'] ?? null,
            'original_url' => $data['editUrl'],
            'title' => $data['editTitle'] ?: null,
            'expires_at' => $data['editExpiresAt'] ?: null,
            'metadata' => $metadata ?: null,
            'tracking_rules' => $trackingRules ?: null,
        ]);
        $link->tags()->sync(array_map('intval', $data['editTagIds'] ?? []));

        $this->showEditModal = false;
        $this->reset(
            'editingLinkId', 'editingCode', 'editUrl', 'editTitle', 'editExpiresAt', 'editFolderId', 'editCategoryId',
            'editTagIds', 'editUtmSource', 'editUtmMedium', 'editUtmCampaign', 'editUtmTerm', 'editUtmContent', 'editMetadataRows', 'editExtraTrackingRules',
        );
        $this->editMetadataRows = [];
        $this->refreshLists();
        $this->dispatch('link-updated');
    }

    public function toggle(int $id): void
    {
        $link = $this->teamLink($id);
        $link->update(['is_active' => ! $link->is_active]);
        unset($this->links);
    }

    public function delete(int $id): void
    {
        $this->teamLink($id)->delete();
        $this->refreshLists();
    }

    private function isOwnDomain(string $url): bool
    {
        return strtolower((string) parse_url($url, PHP_URL_HOST)) === strtolower(request()->getHost());
    }

    public function addMetadataRow(string $target = 'create'): void
    {
        $property = $target === 'edit' ? 'editMetadataRows' : 'metadataRows';
        $this->{$property}[] = ['key' => '', 'value' => '', 'mode' => 'store', 'parameter' => ''];
    }

    public function removeMetadataRow(int $index, string $target = 'create'): void
    {
        $property = $target === 'edit' ? 'editMetadataRows' : 'metadataRows';
        unset($this->{$property}[$index]);
        $this->{$property} = array_values($this->{$property});
    }

    /** Convert key/value editor rows to the persisted JSON data and redirect mapping. */
    private function metadataAndRules(array $rows, string $errorField): ?array
    {
        $metadata = [];
        $rules = ['query' => [], 'utm' => []];

        foreach ($rows as $index => $row) {
            $key = trim((string) ($row['key'] ?? ''));
            $value = (string) ($row['value'] ?? '');
            if ($key === '' && trim($value) === '') {
                continue;
            }
            if ($key === '' || ! preg_match('/^[\pL\pN_. -]{1,100}$/u', $key) || strtolower($key) === 'utm_defaults') {
                $this->addError($errorField.'.'.$index.'.key', 'برای هر مقدار، یک کلید معتبر وارد کنید؛ نام utm_defaults رزرو شده است.');
                return null;
            }

            $metadata[$key] = $value;
            $mode = $row['mode'] ?? 'store';
            $parameter = trim((string) ($row['parameter'] ?? ''));

            if ($mode === 'get') {
                $parameter = $parameter !== '' ? $parameter : $key;
                if (! preg_match('/^[A-Za-z0-9_.-]{1,100}$/', $parameter)) {
                    $this->addError($errorField.'.'.$index.'.parameter', 'نام پارامتر GET معتبر نیست.');
                    return null;
                }
                $rules['query'][$parameter] = '{{'.$key.'}}';
            } elseif ($mode === 'utm') {
                if (! in_array($parameter, ['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content'], true)) {
                    $this->addError($errorField.'.'.$index.'.parameter', 'یک پارامتر معتبر UTM انتخاب کنید.');
                    return null;
                }
                $rules['utm'][$parameter] = '{{'.$key.'}}';
            }
        }

        return [
            'metadata' => $metadata,
            'tracking_rules' => array_filter($rules),
        ];
    }

    /** Keep imported advanced templates that the simple key/value editor cannot represent. */
    private function complexTrackingRules(array $trackingRules, array $metadata): array
    {
        $extra = ['query' => [], 'utm' => []];
        foreach (['query', 'utm'] as $kind) {
            foreach (($trackingRules[$kind] ?? []) as $parameter => $template) {
                $isSimple = false;
                if (is_string($template) && preg_match('/^\{\{\s*([^{}]+?)\s*\}\}$/u', $template, $matches)) {
                    $isSimple = array_key_exists(trim($matches[1]), $metadata);
                } elseif (is_array($template) && isset($template['from'])) {
                    $isSimple = array_key_exists((string) $template['from'], $metadata);
                }
                if (! $isSimple) {
                    $extra[$kind][$parameter] = $template;
                }
            }
        }

        return array_filter($extra);
    }

    private function metadataRowsForEditor(array $metadata, array $trackingRules): array
    {
        $rows = [];
        foreach ($metadata as $key => $value) {
            $matched = false;
            foreach (($trackingRules['query'] ?? []) as $target => $template) {
                if ($template === '{{'.$key.'}}' || (is_array($template) && ($template['from'] ?? null) === $key)) {
                    $rows[] = [
                        'key' => (string) $key,
                        'value' => is_scalar($value) ? (string) $value : (json_encode($value, JSON_UNESCAPED_UNICODE) ?: ''),
                        'mode' => 'get',
                        'parameter' => (string) $target,
                    ];
                    $matched = true;
                }
            }
            foreach (($trackingRules['utm'] ?? []) as $target => $template) {
                if ($template === '{{'.$key.'}}' || (is_array($template) && ($template['from'] ?? null) === $key)) {
                    $rows[] = [
                        'key' => (string) $key,
                        'value' => is_scalar($value) ? (string) $value : (json_encode($value, JSON_UNESCAPED_UNICODE) ?: ''),
                        'mode' => 'utm',
                        'parameter' => (string) $target,
                    ];
                    $matched = true;
                }
            }
            if (! $matched) {
                $rows[] = [
                    'key' => (string) $key,
                    'value' => is_scalar($value) ? (string) $value : (json_encode($value, JSON_UNESCAPED_UNICODE) ?: ''),
                    'mode' => 'store',
                    'parameter' => '',
                ];
            }
        }

        return $rows;
    }

    private function utmDefaults(array $values): array
    {
        return collect($values)
            ->map(fn ($value) => trim((string) $value))
            ->filter(fn ($value) => $value !== '')
            ->all();
    }

    private function refreshLists(): void
    {
        unset($this->links, $this->summary, $this->folders, $this->categories, $this->tags);
    }

    #[Computed]
    public function team(): Team
    {
        return $this->currentTeam();
    }

    #[Computed]
    public function folders()
    {
        return $this->currentTeam()->folders()->orderBy('position')->orderBy('name')->get();
    }

    #[Computed]
    public function categories()
    {
        return $this->currentTeam()->categories()->orderBy('name')->get();
    }

    #[Computed]
    public function tags()
    {
        return $this->currentTeam()->tags()->orderBy('name')->get();
    }

    #[Computed]
    public function summary(): array
    {
        $teamId = $this->currentTeamId();
        $teamClicks = LinkClick::query()->whereHas('link', fn ($query) => $query->where('team_id', $teamId));

        return [
            'links' => Link::forTeam($teamId)->count(),
            'active' => Link::forTeam($teamId)->where('is_active', true)->count(),
            'clicks' => (clone $teamClicks)->count(),
            'visitors' => (clone $teamClicks)->whereNotNull('ip_hash')->distinct('ip_hash')->count('ip_hash'),
            'recent_clicks' => (clone $teamClicks)->where('created_at', '>=', now()->subDays(7))->count(),
        ];
    }

    #[Computed]
    public function links()
    {
        $teamId = $this->currentTeamId();

        return Link::query()
            ->forTeam($teamId)
            ->with(['folder:id,name', 'category:id,name', 'tags:id,name', 'creator:id,name'])
            ->withCount('clickLogs')
            ->when(trim($this->search) !== '', function ($query) {
                $term = '%'.addcslashes(trim($this->search), '%_\\').'%';
                $query->where(function ($query) use ($term) {
                    $query->where('code', 'like', $term)
                        ->orWhere('title', 'like', $term)
                        ->orWhere('original_url', 'like', $term);
                });
            })
            ->when($this->filterFolderId, fn ($query) => $query->where('folder_id', $this->filterFolderId))
            ->when($this->filterCategoryId, fn ($query) => $query->where('category_id', $this->filterCategoryId))
            ->when($this->filterTagId, fn ($query) => $query->whereHas('tags', fn ($tags) => $tags->where('link_tags.id', $this->filterTagId)->where('link_tags.team_id', $teamId)))
            ->latest()
            ->paginate(15);
    }

    protected function view($data = [])
    {
        return app('view')->file('/home3/myrwqtei/AbinotPeyvand/storage/framework/views/livewire/views/13d64db7.blade.php', $data);
    }
};
