<?php

use App\Models\Link;
use App\Models\Team;
use App\Services\Links\LinkImportService;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Livewire\Component;
use Livewire\WithFileUploads;

return new #[Layout('layouts::app')] #[Title('ساخت گروهی و ورود و خروجی')] class extends Component
{
    use WithFileUploads;

    public string $folderName = '';
    public string $defaultUrl = '';
    public string $importContent = '';
    public $importFile = null;
    public array $mappingRows = [];
    public ?string $successMessage = null;

    private function currentTeam(): Team
    {
        $user = auth()->user();
        $team = $user?->currentTeam;
        abort_unless($user && $team && $user->belongsToTeam($team), 403);

        return $team;
    }

    public function addMapping(): void
    {
        $this->mappingRows[] = ['field' => '', 'type' => 'get', 'parameter' => ''];
    }

    public function removeMapping(int $index): void
    {
        unset($this->mappingRows[$index]);
        $this->mappingRows = array_values($this->mappingRows);
    }

    public function import(): void
    {
        $this->resetErrorBag();
        $this->validate([
            'folderName' => ['nullable', 'string', 'max:100'],
            'defaultUrl' => ['nullable', 'url:http,https', 'max:2048'],
            'importContent' => ['nullable', 'string', 'max:2000000'],
            'importFile' => ['nullable', 'file', 'extensions:csv,txt,json', 'max:10240'],
            'mappingRows' => ['array', 'max:30'],
            'mappingRows.*.field' => ['nullable', 'string', 'max:100'],
            'mappingRows.*.type' => ['required', 'in:get,utm'],
            'mappingRows.*.parameter' => ['nullable', 'string', 'max:100'],
        ]);

        $contents = trim($this->importContent);
        $format = 'json';
        if ($this->importFile) {
            $contents = file_get_contents($this->importFile->getRealPath()) ?: '';
            $extension = strtolower($this->importFile->getClientOriginalExtension());
            $preview = ltrim((string) $contents, "\xEF\xBB\xBF \t\n\r\0\x0B");
            $format = in_array($extension, ['csv', 'txt'], true)
                ? ((str_starts_with($preview, '{') || str_starts_with($preview, '[')) ? 'json' : 'csv')
                : 'json';
        } elseif ($contents !== '') {
            $preview = ltrim($contents, "\xEF\xBB\xBF \t\n\r\0\x0B");
            if (! str_starts_with($preview, '{') && ! str_starts_with($preview, '[')) {
                $format = 'csv';
            }
        }

        if (trim((string) $contents) === '') {
            $this->addError('importContent', 'یک فایل CSV/JSON بارگذاری کنید یا محتوای JSON را در کادر قرار دهید.');
            return;
        }

        $service = app(LinkImportService::class);
        $document = $service->parse((string) $contents, $format);
        if (trim($this->folderName) !== '' && empty($document['folder']) && empty($document['defaults']['folder'])) {
            $document['folder'] = trim($this->folderName);
        }
        if (trim($this->defaultUrl) !== '' && empty($document['destination_url']) && empty($document['defaults']['destination_url']) && empty($document['defaults']['url'])) {
            $document['destination_url'] = trim($this->defaultUrl);
        }

        $siteHost = strtolower(request()->getHost());
        $documentDefaults = is_array($document['defaults'] ?? null) ? $document['defaults'] : [];
        $recordsToCheck = $document['records'] ?? $document['links'] ?? [];
        foreach (is_array($recordsToCheck) ? $recordsToCheck : [] as $index => $record) {
            if (! is_array($record)) {
                continue;
            }
            $recordUrl = '';
            foreach (['url', 'destination_url', 'original_url'] as $urlKey) {
                if (is_scalar($record[$urlKey] ?? null) && trim((string) $record[$urlKey]) !== '') {
                    $recordUrl = trim((string) $record[$urlKey]);
                    break;
                }
            }
            $recordUrl = $recordUrl
                ?: (string) ($document['destination_url'] ?? $documentDefaults['destination_url'] ?? $documentDefaults['url'] ?? $this->defaultUrl);
            if (is_string($recordUrl) && filter_var($recordUrl, FILTER_VALIDATE_URL) && strtolower((string) parse_url($recordUrl, PHP_URL_HOST)) === $siteHost) {
                $this->addError('importContent', 'نشانی مقصد در ردیف '.($index + 1).' متعلق به همین سایت است و نمی‌تواند کوتاه شود.');
                return;
            }
        }

        $count = $service->import((int) $this->currentTeam()->id, (int) auth()->id(), $document, $this->mappingRows);
        $this->successMessage = number_format($count).' پیوند با موفقیت در گروه ساخته شد.';
        $this->reset('importContent', 'importFile', 'folderName', 'defaultUrl');
        $this->mappingRows = [];
    }

    public function exportJson()
    {
        $records = $this->exportRecords();
        $document = [
            'format' => 'peyvand-links',
            'version' => 1,
            'records' => $records,
        ];
        $json = json_encode($document, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);

        return response()->streamDownload(function () use ($json) {
            echo $json;
        }, 'peyvand-links-'.$this->currentTeam()->slug.'.json', ['Content-Type' => 'application/json; charset=UTF-8']);
    }

    public function exportCsv()
    {
        $records = $this->exportRecords();
        $metadataKeys = collect($records)->flatMap(fn ($record) => array_keys($record['metadata']))->unique()->sort()->values()->all();
        $reservedHeaders = [
            'url', 'custom_url', 'short_url', 'title', 'folder', 'category', 'tags', 'utm_source', 'utm_medium',
            'utm_campaign', 'utm_term', 'utm_content', 'tracking_json', 'expires_at', 'get', 'query', 'tracking',
        ];
        $metadataColumns = [];
        foreach ($metadataKeys as $key) {
            $header = in_array(strtolower((string) $key), $reservedHeaders, true)
                || str_starts_with(strtolower((string) $key), 'utm_')
                || str_starts_with(strtolower((string) $key), 'get_')
                ? 'meta_'.$key
                : (string) $key;
            while (in_array($header, $reservedHeaders, true) || in_array($header, $metadataColumns, true)) {
                $header = 'meta_'.$header;
            }
            $metadataColumns[$key] = $header;
        }
        $headers = array_merge([
            'url', 'custom_url', 'short_url', 'title', 'expires_at', 'folder', 'category', 'tags',
            'utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'tracking_json',
        ], array_values($metadataColumns));

        return response()->streamDownload(function () use ($records, $headers, $metadataKeys, $metadataColumns) {
            $stream = fopen('php://output', 'w');
            fwrite($stream, "\xEF\xBB\xBF");
            fputcsv($stream, $headers);
            foreach ($records as $record) {
                $row = [
                    $record['url'],
                    $record['custom_url'],
                    $record['short_url'],
                    $record['title'],
                    $record['expires_at'],
                    $record['folder'],
                    $record['category'],
                    implode('|', $record['tags']),
                    $record['utm']['utm_source'] ?? '',
                    $record['utm']['utm_medium'] ?? '',
                    $record['utm']['utm_campaign'] ?? '',
                    $record['utm']['utm_term'] ?? '',
                    $record['utm']['utm_content'] ?? '',
                    json_encode($record['tracking'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?: '{}',
                ];
                foreach ($metadataKeys as $key) {
                    $value = $record['metadata'][$key] ?? '';
                    $row[] = is_scalar($value) ? $value : (json_encode($value, JSON_UNESCAPED_UNICODE) ?: '');
                }
                fputcsv($stream, $row);
            }
            fclose($stream);
        }, 'peyvand-links-'.$this->currentTeam()->slug.'.csv', ['Content-Type' => 'text/csv; charset=UTF-8']);
    }

    private function exportRecords(): array
    {
        return Link::query()
            ->forTeam((int) $this->currentTeam()->id)
            ->with(['folder:id,name', 'category:id,name', 'tags:id,name'])
            ->orderBy('id')
            ->get()
            ->map(function (Link $link) {
                $metadata = $link->metadata ?? [];
                $utm = $metadata['utm_defaults'] ?? [];
                unset($metadata['utm_defaults']);

                return [
                    'url' => $link->original_url,
                    'custom_url' => $link->code,
                    'short_url' => $link->short_url,
                    'title' => $link->title,
                    'expires_at' => $link->expires_at?->toISOString(),
                    'folder' => $link->folder?->name,
                    'category' => $link->category?->name,
                    'tags' => $link->tags->pluck('name')->all(),
                    'metadata' => $metadata,
                    'utm' => $utm,
                    'tracking' => $link->tracking_rules ?? [],
                ];
            })->all();
    }

    #[Computed]
    public function team(): Team
    {
        return $this->currentTeam();
    }

    #[Computed]
    public function linkCount(): int
    {
        return Link::query()->forTeam((int) $this->currentTeam()->id)->count();
    }

    protected function view($data = [])
    {
        return app('view')->file('/home3/myrwqtei/AbinotPeyvand/storage/framework/views/livewire/views/6305518d.blade.php', $data);
    }
};
