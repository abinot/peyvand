<?php

use App\Models\LinkCategory;
use App\Models\LinkFolder;
use App\Models\LinkTag;
use App\Models\Team;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Livewire\Component;

return new #[Layout('layouts::app')] #[Title('مدیریت منابع پیوند')] class extends Component
{
    public string $newType = 'folder';
    public string $newName = '';
    public ?int $editingId = null;
    public string $editingType = 'folder';
    public string $editingName = '';
    public bool $showEditModal = false;

    private function currentTeam(): Team
    {
        $user = auth()->user();
        $team = $user?->currentTeam;
        abort_unless($user && $team && $user->belongsToTeam($team), 403);

        return $team;
    }

    public function create(): void
    {
        $data = $this->validate([
            'newType' => ['required', 'in:folder,category,tag'],
            'newName' => ['required', 'string', 'max:100'],
        ]);

        $name = trim($data['newName']);
        $team = $this->currentTeam();

        if ($data['newType'] === 'folder') {
            $team->folders()->firstOrCreate(['name' => $name]);
        } else {
            $slug = $this->makeSlug($name, $data['newType']);
            $relation = $data['newType'] === 'category' ? $team->categories() : $team->tags();
            $relation->firstOrCreate(['slug' => $slug], ['name' => $name]);
        }

        $this->reset('newName');
        unset($this->folders, $this->categories, $this->tags);
        $this->dispatch('resource-created');
    }

    public function edit(string $type, int $id): void
    {
        $resource = $this->findResource($type, $id);
        $this->editingType = $type;
        $this->editingId = $id;
        $this->editingName = $resource->name;
        $this->showEditModal = true;
    }

    public function update(): void
    {
        $rules = [
            'editingType' => ['required', 'in:folder,category,tag'],
            'editingId' => ['required', 'integer'],
            'editingName' => ['required', 'string', 'max:100'],
        ];
        if ($this->editingType === 'folder' && $this->editingId) {
            $rules['editingName'][] = Rule::unique('link_folders', 'name')
                ->where('team_id', $this->currentTeam()->id)
                ->ignore($this->editingId);
        }
        $data = $this->validate($rules);

        $resource = $this->findResource($data['editingType'], $data['editingId']);
        $name = trim($data['editingName']);
        if ($data['editingType'] === 'folder') {
            $resource->update(['name' => $name]);
        } else {
            $resource->update([
                'name' => $name,
                'slug' => $this->makeSlug($name, $data['editingType'], $resource->id),
            ]);
        }

        $this->showEditModal = false;
        $this->reset('editingId', 'editingName');
        unset($this->folders, $this->categories, $this->tags);
    }

    public function delete(string $type, int $id): void
    {
        $this->findResource($type, $id)->delete();
        unset($this->folders, $this->categories, $this->tags);
    }

    private function findResource(string $type, int $id): LinkFolder|LinkCategory|LinkTag
    {
        $team = $this->currentTeam();

        return match ($type) {
            'folder' => $team->folders()->findOrFail($id),
            'category' => $team->categories()->findOrFail($id),
            'tag' => $team->tags()->findOrFail($id),
            default => abort(404),
        };
    }

    private function makeSlug(string $name, string $type, ?int $ignoreId = null): string
    {
        $base = Str::slug($name) ?: $type.'-'.substr(sha1(mb_strtolower($name)), 0, 10);
        $slug = $base;
        $suffix = 2;
        $relation = $type === 'category' ? $this->currentTeam()->categories() : $this->currentTeam()->tags();

        while ($relation->where('slug', $slug)->when($ignoreId, fn ($query) => $query->where('id', '<>', $ignoreId))->exists()) {
            $slug = $base.'-'.$suffix++;
        }

        return $slug;
    }

    #[Computed]
    public function team(): Team
    {
        return $this->currentTeam();
    }

    #[Computed]
    public function folders()
    {
        return $this->currentTeam()->folders()->withCount('links')->orderBy('position')->orderBy('name')->get();
    }

    #[Computed]
    public function categories()
    {
        return $this->currentTeam()->categories()->withCount('links')->orderBy('name')->get();
    }

    #[Computed]
    public function tags()
    {
        return $this->currentTeam()->tags()->withCount('links')->orderBy('name')->get();
    }

    protected function view($data = [])
    {
        return app('view')->file('/home3/myrwqtei/AbinotPeyvand/storage/framework/views/livewire/views/326f5e8d.blade.php', $data);
    }
};
