<?php
use App\Models\Link;
use App\Models\LinkClick;
use App\Models\Team;
use Illuminate\Validation\Rule;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Locked;
use Livewire\Attributes\Title;
use Livewire\Component;
use Livewire\WithPagination;
?>

<div class="mx-auto max-w-7xl space-y-6 p-6" dir="rtl">
    <div class="flex flex-wrap items-center justify-between gap-3">
        <div>
            <flux:heading size="xl">پیوندهای گروه {{ $this->team->name }}</flux:heading>
            <flux:text class="mt-1">پیوندها و آمار آن‌ها برای همهٔ اعضای این گروه در دسترس است؛ مالک هر رکورد خود گروه است.</flux:text>
        </div>
        <div class="flex flex-wrap gap-2">
            <flux:button href="{{ route('analytics.index') }}" variant="outline">گزارش آمار</flux:button>
            <flux:button href="{{ route('links.bulk') }}" variant="outline">ساخت گروهی و ورود داده</flux:button>
            <flux:button href="{{ route('links.resources') }}" variant="outline">مدیریت پوشه‌ها و برچسب‌ها</flux:button>
        </div>
    </div>

<div class="flex flex-wrap gap-3">
    <flux:card class="w-28 h-28 shrink-0 flex flex-col justify-between p-3">
        <flux:text size="sm">همهٔ پیوندها</flux:text>
        <flux:heading size="xl">{{ number_format($this->summary['links']) }}</flux:heading>
    </flux:card>

    <flux:card class="w-28 h-28 shrink-0 flex flex-col justify-between p-3">
        <flux:text size="sm">پیوندهای فعال</flux:text>
        <flux:heading size="xl">{{ number_format($this->summary['active']) }}</flux:heading>
    </flux:card>

    <flux:card class="w-28 h-28 shrink-0 flex flex-col justify-between p-3">
        <flux:text size="sm">همهٔ کلیک‌ها</flux:text>
        <flux:heading size="xl">{{ number_format($this->summary['clicks']) }}</flux:heading>
    </flux:card>

    <flux:card class="w-28 h-28 shrink-0 flex flex-col justify-between p-3">
        <flux:text size="sm">کلیک‌های ۷ روز اخیر</flux:text>
        <flux:heading size="xl">{{ number_format($this->summary['recent_clicks']) }}</flux:heading>
    </flux:card>

    <flux:card class="w-28 h-28 shrink-0 flex flex-col justify-between p-3">
        <flux:text size="sm">بازدیدکنندگان یکتا</flux:text>
        <flux:heading size="xl">{{ number_format($this->summary['visitors']) }}</flux:heading>
    </flux:card>
</div>

    <div class="grid gap-4 lg:grid-cols-2">
        <flux:card class="space-y-3">
            <flux:heading size="lg">ساخت پیوند کوتاه</flux:heading>
            <form wire:submit="create" class="space-y-4">
                <flux:input wire:model="url" label="نشانی مقصد" placeholder="https://example.com/page" dir="ltr" />
                <div class="grid gap-3 md:grid-cols-2">
                    <flux:input wire:model="title" label="عنوان (اختیاری)" />
                    <flux:input wire:model="customCode" label="کد دلخواه (اختیاری)" dir="ltr" />
                    <flux:input wire:model="expiresAt" type="datetime-local" label="زمان انقضا (اختیاری)" />
                    <flux:select wire:model="folderId" label="پوشه">
                        <flux:select.option value="">بدون پوشه</flux:select.option>
                        @foreach ($this->folders as $folder)
                            <flux:select.option value="{{ $folder->id }}">{{ $folder->name }}</flux:select.option>
                        @endforeach
                    </flux:select>
                    <flux:select wire:model="categoryId" label="دسته‌بندی">
                        <flux:select.option value="">بدون دسته‌بندی</flux:select.option>
                        @foreach ($this->categories as $category)
                            <flux:select.option value="{{ $category->id }}">{{ $category->name }}</flux:select.option>
                        @endforeach
                    </flux:select>
                    <div class="space-y-2 rounded-lg border border-zinc-200 p-3 dark:border-zinc-700">
                        <flux:text class="font-medium">برچسب‌ها</flux:text>
                        @forelse ($this->tags as $tag)
                            <label class="inline-flex items-center gap-2 pl-3 text-sm" wire:key="create-tag-{{ $tag->id }}">
                                <input type="checkbox" wire:model="tagIds" value="{{ $tag->id }}" class="rounded border-zinc-300" />
                                <span>{{ $tag->name }}</span>
                            </label>
                        @empty
                            <flux:text size="xs" class="text-zinc-500">ابتدا برچسب‌ها را در بخش مدیریت منابع بسازید.</flux:text>
                        @endforelse
                    </div>
                </div>

                <div class="space-y-3 rounded-xl border border-zinc-200 p-3 dark:border-zinc-700">
                    <flux:text class="font-medium">پارامترهای پیش‌فرض UTM</flux:text>
                    <div class="grid grid-cols-2 gap-2 sm:grid-cols-3">
                        <flux:input wire:model="utmSource" size="sm" placeholder="utm_source" />
                        <flux:input wire:model="utmMedium" size="sm" placeholder="utm_medium" />
                        <flux:input wire:model="utmCampaign" size="sm" placeholder="utm_campaign" />
                        <flux:input wire:model="utmTerm" size="sm" placeholder="utm_term" />
                        <flux:input wire:model="utmContent" size="sm" placeholder="utm_content" />
                    </div>
                </div>

                <div class="space-y-3 rounded-xl border border-zinc-200 p-3 dark:border-zinc-700">
                    <div class="flex items-center justify-between gap-2">
                        <div>
                            <flux:text class="font-medium">فرادادهٔ سفارشی</flux:text>
                            <flux:text size="xs" class="text-zinc-500">مقدارها در پایگاه داده به‌صورت JSON نگهداری می‌شوند. در اینجا فقط کلید و مقدار را وارد کنید.</flux:text>
                        </div>
                        <flux:button type="button" size="sm" variant="outline" wire:click="addMetadataRow">افزودن ردیف</flux:button>
                    </div>
                    @foreach ($metadataRows as $index => $row)
                        <div class="grid gap-2 rounded-lg bg-zinc-50 p-2 dark:bg-zinc-900 sm:grid-cols-[1fr_1.4fr_1fr_1fr_auto]" wire:key="metadata-create-{{ $index }}">
                            <flux:input wire:model="metadataRows.{{ $index }}.key" placeholder="کلید؛ مثل phone" size="sm" dir="ltr" />
                            <flux:input wire:model="metadataRows.{{ $index }}.value" placeholder="مقدار" size="sm" />
                            <flux:select wire:model="metadataRows.{{ $index }}.mode" size="sm">
                                <flux:select.option value="store">فقط ذخیره شود</flux:select.option>
                                <flux:select.option value="get">ارسال با GET</flux:select.option>
                                <flux:select.option value="utm">استفاده در UTM</flux:select.option>
                            </flux:select>
                            @if (($row['mode'] ?? 'store') === 'utm')
                                <flux:select wire:model="metadataRows.{{ $index }}.parameter" size="sm">
                                    <flux:select.option value="">پارامتر UTM</flux:select.option>
                                    <flux:select.option value="utm_source">utm_source</flux:select.option>
                                    <flux:select.option value="utm_medium">utm_medium</flux:select.option>
                                    <flux:select.option value="utm_campaign">utm_campaign</flux:select.option>
                                    <flux:select.option value="utm_term">utm_term</flux:select.option>
                                    <flux:select.option value="utm_content">utm_content</flux:select.option>
                                </flux:select>
                            @elseif (($row['mode'] ?? 'store') === 'get')
                                <flux:input wire:model="metadataRows.{{ $index }}.parameter" size="sm" placeholder="نام GET (اختیاری)" dir="ltr" />
                            @else
                                <div></div>
                            @endif
                            <flux:button type="button" size="sm" variant="ghost" icon="x-mark" wire:click="removeMetadataRow({{ $index }})" />
                        </div>
                    @endforeach
                    <flux:text size="xs" class="text-zinc-500">برای GET نام پارامتر دلخواه و برای UTM یکی از پارامترهای UTM را انتخاب کنید. برای فرستادن یک مقدار به چند مقصد، همان کلید را در چند ردیف به‌کار ببرید.</flux:text>
                    <flux:error name="metadataRows" />
                </div>

                <div class="flex justify-end"><flux:button type="submit" variant="primary">ساخت پیوند</flux:button></div>
            </form>
        </flux:card>

        <flux:card class="space-y-3">
            <flux:heading size="lg">فیلتر پیوندهای گروه</flux:heading>
            <flux:input wire:model.live.debounce.300ms="search" placeholder="جست‌وجو در عنوان، کد یا مقصد…" icon="magnifying-glass" />
            <div class="grid gap-3 sm:grid-cols-2">
                <flux:select wire:model.live="filterFolderId" label="پوشه">
                    <flux:select.option value="">همهٔ پوشه‌ها</flux:select.option>
                    @foreach ($this->folders as $folder)
                        <flux:select.option value="{{ $folder->id }}">{{ $folder->name }}</flux:select.option>
                    @endforeach
                </flux:select>
                <flux:select wire:model.live="filterCategoryId" label="دسته‌بندی">
                    <flux:select.option value="">همهٔ دسته‌ها</flux:select.option>
                    @foreach ($this->categories as $category)
                        <flux:select.option value="{{ $category->id }}">{{ $category->name }}</flux:select.option>
                    @endforeach
                </flux:select>
                <flux:select wire:model.live="filterTagId" label="برچسب">
                    <flux:select.option value="">همهٔ برچسب‌ها</flux:select.option>
                    @foreach ($this->tags as $tag)
                        <flux:select.option value="{{ $tag->id }}">{{ $tag->name }}</flux:select.option>
                    @endforeach
                </flux:select>
            </div>
            <div class="flex justify-end"><flux:button variant="ghost" wire:click="$set('search', '')">پاک‌کردن جست‌وجو</flux:button></div>
        </flux:card>



    </div>

    <flux:card class="space-y-4">
        <flux:heading size="lg">فهرست پیوندهای گروه</flux:heading>
        <flux:table :paginate="$this->links">
            <flux:table.columns>
                <flux:table.column>پیوند کوتاه</flux:table.column>
                <flux:table.column>عنوان و مقصد</flux:table.column>
                <flux:table.column>دسته‌بندی</flux:table.column>
                <flux:table.column align="end">کلیک‌ها</flux:table.column>
                <flux:table.column>وضعیت</flux:table.column>
                <flux:table.column>عملیات</flux:table.column>
            </flux:table.columns>
            <flux:table.rows>
                @forelse ($this->links as $link)
                    <flux:table.row :key="$link->id">
                        <flux:table.cell>
                            <a href="{{ $link->short_url }}" target="_blank" rel="noopener noreferrer" class="font-medium underline" dir="ltr">{{ $link->short_url }}</a>
                            <div class="mt-1 text-xs text-zinc-500" dir="ltr">/{{ $link->code }}</div>
                        </flux:table.cell>
                        <flux:table.cell>
                            <div class="max-w-sm space-y-1">
                                <div class="font-medium">{{ $link->title ?: 'بدون عنوان' }}</div>
                                <div class="truncate text-xs text-zinc-500" dir="ltr" title="{{ $link->original_url }}">{{ $link->original_url }}</div>
                                <div class="flex flex-wrap gap-1 text-xs text-zinc-500">
                                    @if ($link->folder)<span>{{ $link->folder->name }}</span>@endif
                                    @foreach ($link->tags as $tag)<flux:badge size="sm">{{ $tag->name }}</flux:badge>@endforeach
                                </div>
                            </div>
                        </flux:table.cell>
                        <flux:table.cell>{{ $link->category?->name ?: '—' }}</flux:table.cell>
                        <flux:table.cell align="end">{{ number_format($link->click_logs_count) }}</flux:table.cell>
                        <flux:table.cell>
                            <flux:badge :color="$link->isUsable() ? 'green' : 'zinc'">{{ $link->isUsable() ? 'فعال' : 'غیرفعال / منقضی' }}</flux:badge>
                        </flux:table.cell>
                        <flux:table.cell>
                            <div class="flex flex-wrap gap-1">
                                <flux:button size="sm" wire:click="edit({{ $link->id }})">ویرایش</flux:button>
                                <flux:button size="sm" x-data x-on:click="navigator.clipboard.writeText(@js($link->short_url))">کپی</flux:button>
                                <flux:button size="sm" wire:click="toggle({{ $link->id }})">{{ $link->is_active ? 'غیرفعال‌سازی' : 'فعال‌سازی' }}</flux:button>
                                <flux:button size="sm" variant="danger" wire:click="delete({{ $link->id }})" wire:confirm="این پیوند حذف شود؟">حذف</flux:button>
                            </div>
                            <div class="mt-1 text-xs text-zinc-500">سازنده: {{ $link->creator?->name ?? '—' }}</div>
                        </flux:table.cell>
                    </flux:table.row>
                @empty
                    <flux:table.row>
                        <flux:table.cell colspan="6" class="py-10 text-center text-zinc-500">پیوندی با این شرایط پیدا نشد.</flux:table.cell>
                    </flux:table.row>
                @endforelse
            </flux:table.rows>
        </flux:table>
    </flux:card>

    <flux:modal wire:model="showEditModal" class="md:w-[48rem]">
        <form wire:submit="saveEdit" class="space-y-4">
            <div>
                <flux:heading size="lg">ویرایش پیوند</flux:heading>
                <flux:text size="sm">کد کوتاه ثابت می‌ماند؛ مقصد و ویژگی‌های پیوند تغییر می‌کنند.</flux:text>
            </div>
            @if ($editingLinkId)
                <flux:field>
                    <flux:label>کد کوتاه (ثابت)</flux:label>
                    <flux:input :value="$editingCode" disabled dir="ltr" />
                </flux:field>
            @endif
            <flux:input wire:model="editTitle" label="عنوان" />
            <flux:input wire:model="editUrl" label="نشانی مقصد جدید" dir="ltr" />
            <div class="grid gap-3 sm:grid-cols-2">
                <flux:input wire:model="editExpiresAt" type="datetime-local" label="زمان انقضا" />
                <flux:select wire:model="editFolderId" label="پوشه">
                    <flux:select.option value="">بدون پوشه</flux:select.option>
                    @foreach ($this->folders as $folder)
                        <flux:select.option value="{{ $folder->id }}">{{ $folder->name }}</flux:select.option>
                    @endforeach
                </flux:select>
                <flux:select wire:model="editCategoryId" label="دسته‌بندی">
                    <flux:select.option value="">بدون دسته‌بندی</flux:select.option>
                    @foreach ($this->categories as $category)
                        <flux:select.option value="{{ $category->id }}">{{ $category->name }}</flux:select.option>
                    @endforeach
                </flux:select>
                <div class="space-y-2 rounded-lg border border-zinc-200 p-3 dark:border-zinc-700">
                    <flux:text class="font-medium">برچسب‌ها</flux:text>
                    @forelse ($this->tags as $tag)
                        <label class="inline-flex items-center gap-2 pl-3 text-sm" wire:key="edit-tag-{{ $tag->id }}">
                            <input type="checkbox" wire:model="editTagIds" value="{{ $tag->id }}" class="rounded border-zinc-300" />
                            <span>{{ $tag->name }}</span>
                        </label>
                    @empty
                        <flux:text size="xs" class="text-zinc-500">برچسبی برای انتخاب وجود ندارد.</flux:text>
                    @endforelse
                </div>
            </div>
            <div class="rounded-xl border border-zinc-200 p-3 dark:border-zinc-700">
                <flux:text class="mb-2 font-medium">پارامترهای پیش‌فرض UTM</flux:text>
                <div class="grid gap-2 sm:grid-cols-2">
                    <flux:input wire:model="editUtmSource" size="sm" placeholder="utm_source" />
                    <flux:input wire:model="editUtmMedium" size="sm" placeholder="utm_medium" />
                    <flux:input wire:model="editUtmCampaign" size="sm" placeholder="utm_campaign" />
                    <flux:input wire:model="editUtmTerm" size="sm" placeholder="utm_term" />
                    <flux:input wire:model="editUtmContent" size="sm" placeholder="utm_content" />
                </div>
            </div>
            <div class="space-y-3 rounded-xl border border-zinc-200 p-3 dark:border-zinc-700">
                <div class="flex items-center justify-between gap-2">
                    <flux:text class="font-medium">فرادادهٔ سفارشی</flux:text>
                    <flux:button type="button" size="sm" variant="outline" wire:click="addMetadataRow('edit')">افزودن ردیف</flux:button>
                </div>
                @foreach ($editMetadataRows as $index => $row)
                    <div class="grid gap-2 rounded-lg bg-zinc-50 p-2 dark:bg-zinc-900 sm:grid-cols-[1fr_1.4fr_1fr_1fr_auto]" wire:key="metadata-edit-{{ $index }}">
                        <flux:input wire:model="editMetadataRows.{{ $index }}.key" placeholder="کلید" size="sm" dir="ltr" />
                        <flux:input wire:model="editMetadataRows.{{ $index }}.value" placeholder="مقدار" size="sm" />
                        <flux:select wire:model="editMetadataRows.{{ $index }}.mode" size="sm">
                            <flux:select.option value="store">فقط ذخیره شود</flux:select.option>
                            <flux:select.option value="get">ارسال با GET</flux:select.option>
                            <flux:select.option value="utm">استفاده در UTM</flux:select.option>
                        </flux:select>
                        @if (($row['mode'] ?? 'store') === 'utm')
                            <flux:select wire:model="editMetadataRows.{{ $index }}.parameter" size="sm">
                                <flux:select.option value="">پارامتر UTM</flux:select.option>
                                <flux:select.option value="utm_source">utm_source</flux:select.option>
                                <flux:select.option value="utm_medium">utm_medium</flux:select.option>
                                <flux:select.option value="utm_campaign">utm_campaign</flux:select.option>
                                <flux:select.option value="utm_term">utm_term</flux:select.option>
                                <flux:select.option value="utm_content">utm_content</flux:select.option>
                            </flux:select>
                        @elseif (($row['mode'] ?? 'store') === 'get')
                            <flux:input wire:model="editMetadataRows.{{ $index }}.parameter" placeholder="نام GET (اختیاری)" size="sm" dir="ltr" />
                        @else
                            <div></div>
                        @endif
                        <flux:button type="button" size="sm" variant="ghost" icon="x-mark" wire:click="removeMetadataRow({{ $index }}, 'edit')" />
                    </div>
                @endforeach
                <flux:text size="xs" class="text-zinc-500">فراداده در پایگاه داده به‌صورت JSON ذخیره می‌شود؛ لازم نیست خود JSON را ویرایش کنید.</flux:text>
                <flux:error name="editMetadataRows" />
            </div>
            <div class="flex justify-end gap-2">
                <flux:modal.close><flux:button type="button" variant="ghost">انصراف</flux:button></flux:modal.close>
                <flux:button type="submit" variant="primary">ذخیره تغییرات</flux:button>
            </div>
        </form>
    </flux:modal>
</div>