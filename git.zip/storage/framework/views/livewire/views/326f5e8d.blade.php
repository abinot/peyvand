<?php
use App\Models\LinkCategory;
use App\Models\LinkFolder;
use App\Models\LinkTag;
use App\Models\Team;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Livewire\Component;
?>

<div class="mx-auto max-w-6xl space-y-6 p-6" dir="rtl">
    <div class="flex flex-wrap items-center justify-between gap-3">
        <div>
            <flux:heading size="xl">مدیریت پوشه‌ها، دسته‌بندی‌ها و برچسب‌ها</flux:heading>
            <flux:text class="mt-1">این منابع میان همهٔ اعضای گروه {{ $this->team->name }} مشترک‌اند و در صفحهٔ ساخت/ویرایش پیوند انتخاب می‌شوند.</flux:text>
        </div>
        <flux:button href="{{ route('links.index') }}" variant="outline">بازگشت به پیوندها</flux:button>
    </div>

    <flux:card class="space-y-3">
        <flux:heading size="lg">افزودن منبع</flux:heading>
        <form wire:submit="create" class="grid gap-3 sm:grid-cols-[1fr_2fr_auto]">
            <flux:select wire:model="newType" label="نوع">
                <flux:select.option value="folder">پوشه</flux:select.option>
                <flux:select.option value="category">دسته‌بندی</flux:select.option>
                <flux:select.option value="tag">برچسب / تگ</flux:select.option>
            </flux:select>
            <flux:input wire:model="newName" label="نام" placeholder="مثلاً کمپین تبلیغاتی - پیامکی شماره ۷" />
            <div class="flex items-end"><flux:button type="submit" variant="primary">افزودن</flux:button></div>
        </form>
    </flux:card>

    <div class="grid gap-4 lg:grid-cols-3">
        @foreach ([['key' => 'folders', 'title' => 'پوشه‌ها', 'type' => 'folder', 'items' => $this->folders], ['key' => 'categories', 'title' => 'دسته‌بندی‌ها', 'type' => 'category', 'items' => $this->categories], ['key' => 'tags', 'title' => 'برچسب‌ها / تگ‌ها', 'type' => 'tag', 'items' => $this->tags]] as $group)
            <flux:card class="space-y-3" wire:key="resource-group-{{ $group['key'] }}">
                <div class="flex items-center justify-between gap-2">
                    <flux:heading size="lg">{{ $group['title'] }}</flux:heading>
                    <flux:badge>{{ number_format($group['items']->count()) }}</flux:badge>
                </div>
                <flux:table>
                    <flux:table.columns>
                        <flux:table.column>نام</flux:table.column>
                        <flux:table.column align="end">پیوندها</flux:table.column>
                        <flux:table.column>عملیات</flux:table.column>
                    </flux:table.columns>
                    <flux:table.rows>
                        @forelse ($group['items'] as $item)
                            <flux:table.row :key="$group['key'].'-'.$item->id">
                                <flux:table.cell>{{ $item->name }}</flux:table.cell>
                                <flux:table.cell align="end">{{ number_format($item->links_count) }}</flux:table.cell>
                                <flux:table.cell>
                                    <div class="flex gap-1">
                                        <flux:button size="sm" variant="outline" wire:click="edit('{{ $group['type'] }}', {{ $item->id }})">ویرایش</flux:button>
                                        <flux:button size="sm" variant="danger" wire:click="delete('{{ $group['type'] }}', {{ $item->id }})" wire:confirm="این مورد حذف شود؟ پیوندها از این منبع جدا می‌شوند.">حذف</flux:button>
                                    </div>
                                </flux:table.cell>
                            </flux:table.row>
                        @empty
                            <flux:table.row><flux:table.cell colspan="3" class="py-6 text-center text-zinc-500">موردی ثبت نشده است.</flux:table.cell></flux:table.row>
                        @endforelse
                    </flux:table.rows>
                </flux:table>
            </flux:card>
        @endforeach
    </div>

    <flux:modal wire:model="showEditModal" class="max-w-md">
        <form wire:submit="update" class="space-y-4">
            <flux:heading size="lg">ویرایش منبع</flux:heading>
            <flux:input wire:model="editingName" label="نام" />
            <div class="flex justify-end gap-2">
                <flux:modal.close><flux:button type="button" variant="ghost">انصراف</flux:button></flux:modal.close>
                <flux:button type="submit" variant="primary">ذخیره</flux:button>
            </div>
        </form>
    </flux:modal>
</div>