<?php
use App\Models\Link;
use App\Models\Team;
use App\Services\Links\LinkImportService;
use Livewire\Attributes\Computed;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Livewire\Component;
use Livewire\WithFileUploads;
?>

<div class="mx-auto max-w-5xl space-y-6 p-6" dir="rtl">
    <div class="flex flex-wrap items-center justify-between gap-3">
        <div>
            <flux:heading size="xl">ساخت گروهی و ورود و خروجی داده</flux:heading>
            <flux:text class="mt-1">برای گروه {{ $this->team->name }}؛ هر سطر به یک پیوند عادی و مستقل تبدیل می‌شود.</flux:text>
        </div>
        <div class="flex gap-2">
            <flux:button href="{{ route('links.index') }}" variant="outline">بازگشت به پیوندها</flux:button>
            <flux:button href="{{ route('links.resources') }}" variant="outline">مدیریت منابع</flux:button>
        </div>
    </div>

    @if ($successMessage)
        <flux:callout color="green">{{ $successMessage }}</flux:callout>
    @endif

    <flux:card class="space-y-4">
        <div>
            <flux:heading size="lg">ساخت گروهی از CSV یا JSON</flux:heading>
            <flux:text size="sm" class="mt-1">فایل را از Excel به CSV UTF-8 تبدیل کنید یا خروجی JSON آماده‌شده توسط هوش مصنوعی را بارگذاری/جای‌گذاری کنید.</flux:text>
        </div>
        <form wire:submit="import" class="space-y-4">
            <div class="grid gap-3 md:grid-cols-2">
                <flux:input wire:model="folderName" label="پوشهٔ پیش‌فرض" placeholder="کمپین تبلیغاتی - پیامکی شماره ۷" />
                <flux:input wire:model="defaultUrl" label="نشانی مقصد پیش‌فرض (اختیاری)" placeholder="https://example.com/landing" dir="ltr" />
            </div>
            <flux:field>
                <flux:label>فایل داده</flux:label>
                <input type="file" wire:model="importFile" accept=".csv,.json,.txt" class="block w-full rounded-lg border border-zinc-300 p-3 text-sm dark:border-zinc-700" />
                <flux:description>CSV با سطر عنوان ستون‌ها یا فایل JSON. حداکثر اندازه: ۱۰ مگابایت.</flux:description>
                <flux:error name="importFile" />
            </flux:field>
            <div class="text-center text-xs text-zinc-500">یا JSON را مستقیماً اینجا جای‌گذاری کنید</div>
            <flux:textarea wire:model="importContent" rows="9" dir="ltr" class="font-mono text-xs" placeholder='{
  "folder": "کمپین تبلیغاتی - پیامکی شماره ۷",
  "records": [
    {
      "url": "https://example.com/offer",
      "title": "علی رضایی",
      "metadata": {"first_name": "علی", "last_name": "رضایی", "phone": "09120000000", "gender": "male"},
      "utm": {"utm_source": "sms", "utm_medium": "sms", "utm_content": "&#123;&#123;phone&#125;&#125;"},
      "get": {"phone": "&#123;&#123;phone&#125;&#125;", "gender": "&#123;&#123;gender&#125;&#125;"}
    }
  ]
}' />
            <flux:error name="importContent" />

            <flux:callout color="amber" icon="eye">
                هر فیلدی که به GET یا UTM نگاشت شود، در نشانی مقصد قرار می‌گیرد و ممکن است در نوار نشانی، تاریخچهٔ مرورگر و گزارش‌های سرور مقصد دیده شود. اطلاعات حساسی مانند شمارهٔ همراه را فقط در صورت نیاز و با مجوز مناسب ارسال کنید.
            </flux:callout>

            <div class="space-y-3 rounded-xl border border-zinc-200 p-3 dark:border-zinc-700">
                <div class="flex flex-wrap items-center justify-between gap-2">
                    <div>
                        <flux:text class="font-medium">نگاشت ستون‌ها و فراداده</flux:text>
                        <flux:text size="xs" class="text-zinc-500">برای CSV مشخص کنید کدام فیلد به‌صورت GET یا UTM به نشانی مقصد فرستاده شود.</flux:text>
                    </div>
                    <flux:button type="button" size="sm" variant="outline" wire:click="addMapping">افزودن نگاشت</flux:button>
                </div>
                @foreach ($mappingRows as $index => $mapping)
                    <div class="grid gap-2 sm:grid-cols-[1fr_1fr_1fr_auto]" wire:key="mapping-{{ $index }}">
                        <flux:input wire:model="mappingRows.{{ $index }}.field" size="sm" placeholder="نام فیلد؛ مثل phone" dir="ltr" />
                        <flux:select wire:model="mappingRows.{{ $index }}.type" size="sm">
                            <flux:select.option value="get">پارامتر GET</flux:select.option>
                            <flux:select.option value="utm">پارامتر UTM</flux:select.option>
                        </flux:select>
                        <flux:input wire:model="mappingRows.{{ $index }}.parameter" size="sm" placeholder="نام پارامتر؛ مثل phone یا utm_content" dir="ltr" />
                        <flux:button type="button" size="sm" variant="ghost" icon="x-mark" wire:click="removeMapping({{ $index }})" />
                    </div>
                @endforeach
            </div>

            <div class="flex justify-end">
                <flux:button type="submit" variant="primary" wire:loading.attr="disabled" wire:target="import,importFile">ساخت پیوندها از داده‌ها</flux:button>
            </div>
        </form>
    </flux:card>

    <flux:card class="space-y-3">
        <div class="flex flex-wrap items-center justify-between gap-2">
            <div>
                <flux:heading size="lg">خروجی گروه</flux:heading>
                <flux:text size="sm">{{ number_format($this->linkCount) }} پیوند در گروه وجود دارد.</flux:text>
            </div>
            <div class="flex flex-wrap gap-2">
                <flux:button wire:click="exportCsv" icon="arrow-down-tray" variant="outline">دریافت CSV برای Excel</flux:button>
                <flux:button wire:click="exportJson" icon="code-bracket" variant="outline">دریافت JSON</flux:button>
            </div>
        </div>
        <flux:text size="sm" class="text-zinc-500">خروجی JSON تمام اطلاعات، فراداده‌ها، UTM و نگاشت GET را نگه می‌دارد. در CSV ستون‌های اضافی با پیشوند meta_ همان فراداده‌ها هستند.</flux:text>
    </flux:card>

    <flux:card class="space-y-2">
        <flux:heading size="lg">قواعد داده</flux:heading>
        <ul class="list-disc space-y-1 pr-5 text-sm text-zinc-600 dark:text-zinc-300">
            <li>هر رکورد یک پیوند مستقل در گروه جاری می‌سازد؛ هیچ موجودیت جداگانه‌ای برای پیامک یا کارزار ایجاد نمی‌شود.</li>
            <li>فیلدهای <code dir="ltr">url</code> یا <code dir="ltr">destination_url</code> نشانی مقصد هستند؛ <code dir="ltr">custom_url</code> یا <code dir="ltr">code</code> کد کوتاه دلخواه است.</li>
            <li>اگر کد کوتاه خالی باشد، کد تصادفی ساخته می‌شود. اگر پوشه وجود نداشته باشد، هنگام ورود داده ساخته خواهد شد.</li>
            <li>فیلدهای اضافی مانند <code dir="ltr">phone</code>، <code dir="ltr">gender</code>، <code dir="ltr">first_name</code> و <code dir="ltr">last_name</code> در فرادادهٔ JSON همان پیوند ذخیره می‌شوند.</li>
            <li>برای مقادیر پویا از الگوی <code dir="ltr">&#123;&#123;phone&#125;&#125;</code> استفاده کنید؛ مقدار از کلید <code dir="ltr">phone</code> در فراداده خوانده می‌شود.</li>
        </ul>
    </flux:card>
</div>