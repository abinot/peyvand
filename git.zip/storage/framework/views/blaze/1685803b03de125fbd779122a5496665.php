<?php
if (!function_exists('__1685803b03de125fbd779122a5496665')):
function __1685803b03de125fbd779122a5496665($__blaze, $__data = [], $__slots = [], $__bound = [], $__keys = [], $__this = null) {
$__env = $__blaze->env;
$__slots['slot'] ??= new \Illuminate\View\ComponentSlot('');
if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP);
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::make($__data, $__bound, $__keys);
unset($__data, $__bound, $__keys);
ob_start();
?>


<?php
extract(Flux::forwardedAttributes($attributes, [
    'name',
    'descriptionTrailing',
    'description',
    'label',
    'badge',
]));
?>

<?php $descriptionTrailing = $descriptionTrailing ??= $attributes->pluck('description:trailing'); ?>

<?php
$__defaults = [
    'name' => $attributes->whereStartsWith('wire:model')->first(),
    'descriptionTrailing' => null,
    'description' => null,
    'label' => null,
    'badge' => null,
];
$name ??= $attributes['name'] ?? $__defaults['name']; unset($attributes['name']);
$descriptionTrailing ??= $attributes['description-trailing'] ?? $attributes['descriptionTrailing'] ?? $__defaults['descriptionTrailing']; unset($attributes['descriptionTrailing'], $attributes['description-trailing']);
$description ??= $attributes['description'] ?? $__defaults['description']; unset($attributes['description']);
$label ??= $attributes['label'] ?? $__defaults['label']; unset($attributes['label']);
$badge ??= $attributes['badge'] ?? $__defaults['badge']; unset($attributes['badge']);
unset($__defaults);
?>

<?php if (isset($label) || isset($description) || isset($descriptionTrailing)): ?>
    <?php

        $fieldAttributes = Flux::attributesAfter('field:', $attributes, []);
        $labelAttributes = Flux::attributesAfter('label:', $attributes, ['badge' => $badge]);
        $descriptionAttributes = Flux::attributesAfter('description:', $attributes, []);
        $errorAttributes = Flux::attributesAfter('error:', $attributes, ['name' => $name]);
    ?>
    <?php if (!function_exists('__1029856aa2789caaa021cc05795cd375')) { $__blaze->compile('/home3/myrwqtei/AbinotPeyvand/vendor/livewire/flux/src/../stubs/resources/views/flux/field.blade.php', $__blaze->compiledPath.'/1029856aa2789caaa021cc05795cd375.php'); require $__blaze->compiledPath.'/1029856aa2789caaa021cc05795cd375.php'; } ?>
<?php if (isset($__slots1029856aa2789caaa021cc05795cd375)) { $__slotsStack1029856aa2789caaa021cc05795cd375[] = $__slots1029856aa2789caaa021cc05795cd375; } ?>
<?php if (isset($__attrs1029856aa2789caaa021cc05795cd375)) { $__attrsStack1029856aa2789caaa021cc05795cd375[] = $__attrs1029856aa2789caaa021cc05795cd375; } ?>
<?php $__attrs1029856aa2789caaa021cc05795cd375 = ['attributes' => $fieldAttributes]; ?>
<?php $__slots1029856aa2789caaa021cc05795cd375 = []; ?>
<?php $__blaze->pushData($__attrs1029856aa2789caaa021cc05795cd375); ?>
<?php ob_start(); ?>
        <?php if (isset($label)): ?>
            <?php if (!function_exists('__7979a309ef9dec468bca7fab0c7ee801')) { $__blaze->compile('/home3/myrwqtei/AbinotPeyvand/vendor/livewire/flux/src/../stubs/resources/views/flux/label.blade.php', $__blaze->compiledPath.'/7979a309ef9dec468bca7fab0c7ee801.php'); require $__blaze->compiledPath.'/7979a309ef9dec468bca7fab0c7ee801.php'; } ?>
<?php if (isset($__slots7979a309ef9dec468bca7fab0c7ee801)) { $__slotsStack7979a309ef9dec468bca7fab0c7ee801[] = $__slots7979a309ef9dec468bca7fab0c7ee801; } ?>
<?php if (isset($__attrs7979a309ef9dec468bca7fab0c7ee801)) { $__attrsStack7979a309ef9dec468bca7fab0c7ee801[] = $__attrs7979a309ef9dec468bca7fab0c7ee801; } ?>
<?php $__attrs7979a309ef9dec468bca7fab0c7ee801 = ['attributes' => $labelAttributes]; ?>
<?php $__slots7979a309ef9dec468bca7fab0c7ee801 = []; ?>
<?php $__blaze->pushData($__attrs7979a309ef9dec468bca7fab0c7ee801); ?>
<?php ob_start(); ?><?php echo e($label); ?><?php $__slots7979a309ef9dec468bca7fab0c7ee801['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slots7979a309ef9dec468bca7fab0c7ee801); ?>
<?php __7979a309ef9dec468bca7fab0c7ee801($__blaze, $__attrs7979a309ef9dec468bca7fab0c7ee801, $__slots7979a309ef9dec468bca7fab0c7ee801, ['attributes'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack7979a309ef9dec468bca7fab0c7ee801)) { $__slots7979a309ef9dec468bca7fab0c7ee801 = array_pop($__slotsStack7979a309ef9dec468bca7fab0c7ee801); } ?>
<?php if (! empty($__attrsStack7979a309ef9dec468bca7fab0c7ee801)) { $__attrs7979a309ef9dec468bca7fab0c7ee801 = array_pop($__attrsStack7979a309ef9dec468bca7fab0c7ee801); } ?>
<?php $__blaze->popData(); ?>
        <?php endif; ?>

        <?php if (isset($description)): ?>
            <?php if (!function_exists('__b4cef93476eac6202cd4c7c11cf0c6c3')) { $__blaze->compile('/home3/myrwqtei/AbinotPeyvand/vendor/livewire/flux/src/../stubs/resources/views/flux/description.blade.php', $__blaze->compiledPath.'/b4cef93476eac6202cd4c7c11cf0c6c3.php'); require $__blaze->compiledPath.'/b4cef93476eac6202cd4c7c11cf0c6c3.php'; } ?>
<?php if (isset($__slotsb4cef93476eac6202cd4c7c11cf0c6c3)) { $__slotsStackb4cef93476eac6202cd4c7c11cf0c6c3[] = $__slotsb4cef93476eac6202cd4c7c11cf0c6c3; } ?>
<?php if (isset($__attrsb4cef93476eac6202cd4c7c11cf0c6c3)) { $__attrsStackb4cef93476eac6202cd4c7c11cf0c6c3[] = $__attrsb4cef93476eac6202cd4c7c11cf0c6c3; } ?>
<?php $__attrsb4cef93476eac6202cd4c7c11cf0c6c3 = ['attributes' => $descriptionAttributes]; ?>
<?php $__slotsb4cef93476eac6202cd4c7c11cf0c6c3 = []; ?>
<?php $__blaze->pushData($__attrsb4cef93476eac6202cd4c7c11cf0c6c3); ?>
<?php ob_start(); ?><?php echo e($description); ?><?php $__slotsb4cef93476eac6202cd4c7c11cf0c6c3['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slotsb4cef93476eac6202cd4c7c11cf0c6c3); ?>
<?php __b4cef93476eac6202cd4c7c11cf0c6c3($__blaze, $__attrsb4cef93476eac6202cd4c7c11cf0c6c3, $__slotsb4cef93476eac6202cd4c7c11cf0c6c3, ['attributes'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackb4cef93476eac6202cd4c7c11cf0c6c3)) { $__slotsb4cef93476eac6202cd4c7c11cf0c6c3 = array_pop($__slotsStackb4cef93476eac6202cd4c7c11cf0c6c3); } ?>
<?php if (! empty($__attrsStackb4cef93476eac6202cd4c7c11cf0c6c3)) { $__attrsb4cef93476eac6202cd4c7c11cf0c6c3 = array_pop($__attrsStackb4cef93476eac6202cd4c7c11cf0c6c3); } ?>
<?php $__blaze->popData(); ?>
        <?php endif; ?>

        <?php echo e($slot); ?>


        
        [STARTCOMPILEDUNBLAZE:boQR2L7NRS]<?php \Livewire\Blaze\Unblaze::storeScope("boQR2L7NRS", scope: ['attributes' => $errorAttributes->getAttributes()]) ?><?php \Livewire\Blaze\Unblaze::storeReplacement("boQR2L7NRS", "CiAgICAgICAgPGZsdXg6ZXJyb3IgOmF0dHJpYnV0ZXM9Im5ldyBcSWxsdW1pbmF0ZVxWaWV3XENvbXBvbmVudEF0dHJpYnV0ZUJhZygkc2NvcGVbJ2F0dHJpYnV0ZXMnXSkiIC8+CiAgICAgICAg") ?>[ENDCOMPILEDUNBLAZE:boQR2L7NRS]

        <?php if (isset($descriptionTrailing)): ?>
            <?php if (!function_exists('__b4cef93476eac6202cd4c7c11cf0c6c3')) { $__blaze->compile('/home3/myrwqtei/AbinotPeyvand/vendor/livewire/flux/src/../stubs/resources/views/flux/description.blade.php', $__blaze->compiledPath.'/b4cef93476eac6202cd4c7c11cf0c6c3.php'); require $__blaze->compiledPath.'/b4cef93476eac6202cd4c7c11cf0c6c3.php'; } ?>
<?php if (isset($__slotsb4cef93476eac6202cd4c7c11cf0c6c3)) { $__slotsStackb4cef93476eac6202cd4c7c11cf0c6c3[] = $__slotsb4cef93476eac6202cd4c7c11cf0c6c3; } ?>
<?php if (isset($__attrsb4cef93476eac6202cd4c7c11cf0c6c3)) { $__attrsStackb4cef93476eac6202cd4c7c11cf0c6c3[] = $__attrsb4cef93476eac6202cd4c7c11cf0c6c3; } ?>
<?php $__attrsb4cef93476eac6202cd4c7c11cf0c6c3 = ['attributes' => $descriptionAttributes]; ?>
<?php $__slotsb4cef93476eac6202cd4c7c11cf0c6c3 = []; ?>
<?php $__blaze->pushData($__attrsb4cef93476eac6202cd4c7c11cf0c6c3); ?>
<?php ob_start(); ?><?php echo e($descriptionTrailing); ?><?php $__slotsb4cef93476eac6202cd4c7c11cf0c6c3['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slotsb4cef93476eac6202cd4c7c11cf0c6c3); ?>
<?php __b4cef93476eac6202cd4c7c11cf0c6c3($__blaze, $__attrsb4cef93476eac6202cd4c7c11cf0c6c3, $__slotsb4cef93476eac6202cd4c7c11cf0c6c3, ['attributes'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackb4cef93476eac6202cd4c7c11cf0c6c3)) { $__slotsb4cef93476eac6202cd4c7c11cf0c6c3 = array_pop($__slotsStackb4cef93476eac6202cd4c7c11cf0c6c3); } ?>
<?php if (! empty($__attrsStackb4cef93476eac6202cd4c7c11cf0c6c3)) { $__attrsb4cef93476eac6202cd4c7c11cf0c6c3 = array_pop($__attrsStackb4cef93476eac6202cd4c7c11cf0c6c3); } ?>
<?php $__blaze->popData(); ?>
        <?php endif; ?>
    <?php $__slots1029856aa2789caaa021cc05795cd375['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slots1029856aa2789caaa021cc05795cd375); ?>
<?php __1029856aa2789caaa021cc05795cd375($__blaze, $__attrs1029856aa2789caaa021cc05795cd375, $__slots1029856aa2789caaa021cc05795cd375, ['attributes'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack1029856aa2789caaa021cc05795cd375)) { $__slots1029856aa2789caaa021cc05795cd375 = array_pop($__slotsStack1029856aa2789caaa021cc05795cd375); } ?>
<?php if (! empty($__attrsStack1029856aa2789caaa021cc05795cd375)) { $__attrs1029856aa2789caaa021cc05795cd375 = array_pop($__attrsStack1029856aa2789caaa021cc05795cd375); } ?>
<?php $__blaze->popData(); ?>
<?php else: ?>
    <?php echo e($slot); ?>

<?php endif; ?>
<?php
echo $__blaze->processPassthroughContent('ltrim', ltrim(ob_get_clean()));
} endif; ?><?php /**PATH /home3/myrwqtei/AbinotPeyvand/vendor/livewire/flux/src/../stubs/resources/views/flux/with-field.blade.php ENDPATH**/ ?>