<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'sidebar' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'sidebar' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($sidebar): ?>
    <?php if (!function_exists('_bad3a7aec3d894b5dde38262e3a27214')) { $__blaze->compile('/home3/myrwqtei/AbinotPeyvand/vendor/livewire/flux/src/../stubs/resources/views/flux/sidebar/brand.blade.php', $__blaze->compiledPath.'/bad3a7aec3d894b5dde38262e3a27214.php'); require $__blaze->compiledPath.'/bad3a7aec3d894b5dde38262e3a27214.php'; } ?>
<?php if (isset($__slotsbad3a7aec3d894b5dde38262e3a27214)) { $__slotsStackbad3a7aec3d894b5dde38262e3a27214[] = $__slotsbad3a7aec3d894b5dde38262e3a27214; } ?>
<?php if (isset($__attrsbad3a7aec3d894b5dde38262e3a27214)) { $__attrsStackbad3a7aec3d894b5dde38262e3a27214[] = $__attrsbad3a7aec3d894b5dde38262e3a27214; } ?>
<?php $__attrsbad3a7aec3d894b5dde38262e3a27214 = ['name' => config('app.name', 'Laravel'),'attributes' => $attributes]; ?>
<?php $__slotsbad3a7aec3d894b5dde38262e3a27214 = []; ?>
<?php $__blaze->pushData($__attrsbad3a7aec3d894b5dde38262e3a27214); ?>
<?php ob_start(); ?>
         <?php ob_start(); ?>
            <?php if (isset($component)) { $__componentOriginal159d6670770cb479b1921cea6416c26c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal159d6670770cb479b1921cea6416c26c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-logo-icon','data' => ['class' => 'size-5 fill-current text-white dark:text-black']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-logo-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'size-5 fill-current text-white dark:text-black']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal159d6670770cb479b1921cea6416c26c)): ?>
<?php $attributes = $__attributesOriginal159d6670770cb479b1921cea6416c26c; ?>
<?php unset($__attributesOriginal159d6670770cb479b1921cea6416c26c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal159d6670770cb479b1921cea6416c26c)): ?>
<?php $component = $__componentOriginal159d6670770cb479b1921cea6416c26c; ?>
<?php unset($__componentOriginal159d6670770cb479b1921cea6416c26c); ?>
<?php endif; ?>
        <?php $__slotsbad3a7aec3d894b5dde38262e3a27214['logo'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), ['class' => 'flex aspect-square size-8 items-center justify-center rounded-md bg-accent-content text-accent-foreground']); ?>
    <?php $__slotsbad3a7aec3d894b5dde38262e3a27214['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsbad3a7aec3d894b5dde38262e3a27214); ?>
<?php _bad3a7aec3d894b5dde38262e3a27214($__blaze, $__attrsbad3a7aec3d894b5dde38262e3a27214, $__slotsbad3a7aec3d894b5dde38262e3a27214, ['name', 'attributes'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackbad3a7aec3d894b5dde38262e3a27214)) { $__slotsbad3a7aec3d894b5dde38262e3a27214 = array_pop($__slotsStackbad3a7aec3d894b5dde38262e3a27214); } ?>
<?php if (! empty($__attrsStackbad3a7aec3d894b5dde38262e3a27214)) { $__attrsbad3a7aec3d894b5dde38262e3a27214 = array_pop($__attrsStackbad3a7aec3d894b5dde38262e3a27214); } ?>
<?php $__blaze->popData(); ?>
<?php else: ?>
    <?php if (!function_exists('_9f1ae3bdb8a8b0d435057a343d4cbfc4')) { $__blaze->compile('/home3/myrwqtei/AbinotPeyvand/vendor/livewire/flux/src/../stubs/resources/views/flux/brand.blade.php', $__blaze->compiledPath.'/9f1ae3bdb8a8b0d435057a343d4cbfc4.php'); require $__blaze->compiledPath.'/9f1ae3bdb8a8b0d435057a343d4cbfc4.php'; } ?>
<?php if (isset($__slots9f1ae3bdb8a8b0d435057a343d4cbfc4)) { $__slotsStack9f1ae3bdb8a8b0d435057a343d4cbfc4[] = $__slots9f1ae3bdb8a8b0d435057a343d4cbfc4; } ?>
<?php if (isset($__attrs9f1ae3bdb8a8b0d435057a343d4cbfc4)) { $__attrsStack9f1ae3bdb8a8b0d435057a343d4cbfc4[] = $__attrs9f1ae3bdb8a8b0d435057a343d4cbfc4; } ?>
<?php $__attrs9f1ae3bdb8a8b0d435057a343d4cbfc4 = ['name' => config('app.name', 'Laravel'),'attributes' => $attributes]; ?>
<?php $__slots9f1ae3bdb8a8b0d435057a343d4cbfc4 = []; ?>
<?php $__blaze->pushData($__attrs9f1ae3bdb8a8b0d435057a343d4cbfc4); ?>
<?php ob_start(); ?>
         <?php ob_start(); ?>
            <?php if (isset($component)) { $__componentOriginal159d6670770cb479b1921cea6416c26c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal159d6670770cb479b1921cea6416c26c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-logo-icon','data' => ['class' => 'size-5 fill-current text-white dark:text-black']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-logo-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'size-5 fill-current text-white dark:text-black']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal159d6670770cb479b1921cea6416c26c)): ?>
<?php $attributes = $__attributesOriginal159d6670770cb479b1921cea6416c26c; ?>
<?php unset($__attributesOriginal159d6670770cb479b1921cea6416c26c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal159d6670770cb479b1921cea6416c26c)): ?>
<?php $component = $__componentOriginal159d6670770cb479b1921cea6416c26c; ?>
<?php unset($__componentOriginal159d6670770cb479b1921cea6416c26c); ?>
<?php endif; ?>
        <?php $__slots9f1ae3bdb8a8b0d435057a343d4cbfc4['logo'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), ['class' => 'flex aspect-square size-8 items-center justify-center rounded-md bg-accent-content text-accent-foreground']); ?>
    <?php $__slots9f1ae3bdb8a8b0d435057a343d4cbfc4['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots9f1ae3bdb8a8b0d435057a343d4cbfc4); ?>
<?php _9f1ae3bdb8a8b0d435057a343d4cbfc4($__blaze, $__attrs9f1ae3bdb8a8b0d435057a343d4cbfc4, $__slots9f1ae3bdb8a8b0d435057a343d4cbfc4, ['name', 'attributes'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack9f1ae3bdb8a8b0d435057a343d4cbfc4)) { $__slots9f1ae3bdb8a8b0d435057a343d4cbfc4 = array_pop($__slotsStack9f1ae3bdb8a8b0d435057a343d4cbfc4); } ?>
<?php if (! empty($__attrsStack9f1ae3bdb8a8b0d435057a343d4cbfc4)) { $__attrs9f1ae3bdb8a8b0d435057a343d4cbfc4 = array_pop($__attrsStack9f1ae3bdb8a8b0d435057a343d4cbfc4); } ?>
<?php $__blaze->popData(); ?>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php /**PATH /home3/myrwqtei/AbinotPeyvand/resources/views/components/app-logo.blade.php ENDPATH**/ ?>