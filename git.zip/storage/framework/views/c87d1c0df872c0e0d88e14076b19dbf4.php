<?php
if (!function_exists('_c87d1c0df872c0e0d88e14076b19dbf4')):
function _c87d1c0df872c0e0d88e14076b19dbf4($__blaze, $__data = [], $__slots = [], $__bound = [], $__keys = [], $__this = null) {
$__env = $__blaze->env;

if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP);
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::make($__data, $__bound, $__keys);
unset($__data, $__bound, $__keys);
ob_start();
?>


<?php
$__defaults = [
    'name' => null,
];
$name ??= $attributes['name'] ?? $__defaults['name']; unset($attributes['name']);
unset($__defaults);
?>

<?php
// We only want to show the name attribute on the checkbox if it has been set
// manually, but not if it has been set from the wire:model attribute...
$showName = isset($name);

if (! isset($name)) {
    $name = $attributes->whereStartsWith('wire:model')->first();
}

$classes = Flux::classes()
    ->add('flex size-[1.125rem] rounded-[.3rem] mt-px outline-offset-2')
    ;
?>

<?php if (!function_exists('_beb44269b89e6726ab0d77046400b5ef')) { $__blaze->compile('/home3/myrwqtei/AbinotPeyvand/vendor/livewire/flux/src/../stubs/resources/views/flux/with-inline-field.blade.php', $__blaze->compiledPath.'/beb44269b89e6726ab0d77046400b5ef.php'); require $__blaze->compiledPath.'/beb44269b89e6726ab0d77046400b5ef.php'; } ?>
<?php if (isset($__slotsbeb44269b89e6726ab0d77046400b5ef)) { $__slotsStackbeb44269b89e6726ab0d77046400b5ef[] = $__slotsbeb44269b89e6726ab0d77046400b5ef; } ?>
<?php if (isset($__attrsbeb44269b89e6726ab0d77046400b5ef)) { $__attrsStackbeb44269b89e6726ab0d77046400b5ef[] = $__attrsbeb44269b89e6726ab0d77046400b5ef; } ?>
<?php $__attrsbeb44269b89e6726ab0d77046400b5ef = ['attributes' => $attributes]; ?>
<?php $__slotsbeb44269b89e6726ab0d77046400b5ef = []; ?>
<?php $__blaze->pushData($__attrsbeb44269b89e6726ab0d77046400b5ef); ?>
<?php ob_start(); ?>
    <ui-checkbox <?php echo e($attributes->class($classes)); ?> <?php if($showName): ?> name="<?php echo e($name); ?>" <?php endif; ?> data-flux-control data-flux-checkbox>
        <?php $blaze_memoized_key = \Livewire\Blaze\Memoizer\Memo::key("flux::checkbox.indicator", []); ?><?php if ($blaze_memoized_key !== null && \Livewire\Blaze\Memoizer\Memo::has($blaze_memoized_key)) : ?><?php echo \Livewire\Blaze\Memoizer\Memo::get($blaze_memoized_key); ?><?php else : ?><?php ob_start(); ?><?php if (!function_exists('_d60ca70feee812fe568db248be7a5729')) { $__blaze->compile('/home3/myrwqtei/AbinotPeyvand/vendor/livewire/flux/src/../stubs/resources/views/flux/checkbox/indicator.blade.php', $__blaze->compiledPath.'/d60ca70feee812fe568db248be7a5729.php'); require $__blaze->compiledPath.'/d60ca70feee812fe568db248be7a5729.php'; } ?>
<?php $__blaze->pushData([]); ?>
<?php _d60ca70feee812fe568db248be7a5729($__blaze, [], [], [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?><?php $blaze_memoized_html = ob_get_clean(); ?><?php if ($blaze_memoized_key !== null) { \Livewire\Blaze\Memoizer\Memo::put($blaze_memoized_key, $blaze_memoized_html); } ?><?php echo $blaze_memoized_html; ?><?php endif; ?>
    </ui-checkbox>
<?php $__slotsbeb44269b89e6726ab0d77046400b5ef['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsbeb44269b89e6726ab0d77046400b5ef); ?>
<?php _beb44269b89e6726ab0d77046400b5ef($__blaze, $__attrsbeb44269b89e6726ab0d77046400b5ef, $__slotsbeb44269b89e6726ab0d77046400b5ef, ['attributes'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackbeb44269b89e6726ab0d77046400b5ef)) { $__slotsbeb44269b89e6726ab0d77046400b5ef = array_pop($__slotsStackbeb44269b89e6726ab0d77046400b5ef); } ?>
<?php if (! empty($__attrsStackbeb44269b89e6726ab0d77046400b5ef)) { $__attrsbeb44269b89e6726ab0d77046400b5ef = array_pop($__attrsStackbeb44269b89e6726ab0d77046400b5ef); } ?>
<?php $__blaze->popData(); ?>
<?php
echo ltrim(ob_get_clean());
} endif; ?><?php /**PATH /home3/myrwqtei/AbinotPeyvand/vendor/livewire/flux/src/../stubs/resources/views/flux/checkbox/variants/default.blade.php ENDPATH**/ ?>