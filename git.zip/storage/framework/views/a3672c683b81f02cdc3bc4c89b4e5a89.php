<?php
if (!function_exists('_a3672c683b81f02cdc3bc4c89b4e5a89')):
function _a3672c683b81f02cdc3bc4c89b4e5a89($__blaze, $__data = [], $__slots = [], $__bound = [], $__keys = [], $__this = null) {
$__env = $__blaze->env;

if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP);
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::make($__data, $__bound, $__keys);
unset($__data, $__bound, $__keys);
ob_start();
?>


<?php
$__defaults = [
    'iconVariant' => 'mini',
    'size' => null,
];
$iconVariant ??= $attributes['icon-variant'] ?? $attributes['iconVariant'] ?? $__defaults['iconVariant']; unset($attributes['iconVariant'], $attributes['icon-variant']);
$size ??= $attributes['size'] ?? $__defaults['size']; unset($attributes['size']);
unset($__defaults);
?>

<?php
$attributes = $attributes->merge([
    'variant' => 'subtle',
    'class' => '-me-1',
    'square' => true,
    'size' => null,
]);
?>

<?php if (!function_exists('_65233d9163ae832b5948df7c03dc9ee4')) { $__blaze->compile('/home3/myrwqtei/AbinotPeyvand/vendor/livewire/flux/src/../stubs/resources/views/flux/button/index.blade.php', $__blaze->compiledPath.'/65233d9163ae832b5948df7c03dc9ee4.php'); require $__blaze->compiledPath.'/65233d9163ae832b5948df7c03dc9ee4.php'; } ?>
<?php if (isset($__slots65233d9163ae832b5948df7c03dc9ee4)) { $__slotsStack65233d9163ae832b5948df7c03dc9ee4[] = $__slots65233d9163ae832b5948df7c03dc9ee4; } ?>
<?php if (isset($__attrs65233d9163ae832b5948df7c03dc9ee4)) { $__attrsStack65233d9163ae832b5948df7c03dc9ee4[] = $__attrs65233d9163ae832b5948df7c03dc9ee4; } ?>
<?php $__attrs65233d9163ae832b5948df7c03dc9ee4 = ['attributes' => $attributes,'size' => $size === 'sm' || $size === 'xs' ? 'xs' : 'sm','xData' => 'fluxInputViewable','xOn:click' => 'toggle()','xBind:dataViewableOpen' => 'open','ariaLabel' => e(__('Toggle password visibility'))]; ?>
<?php $__slots65233d9163ae832b5948df7c03dc9ee4 = []; ?>
<?php $__blaze->pushData($__attrs65233d9163ae832b5948df7c03dc9ee4); ?>
<?php ob_start(); ?>
    <?php if (!function_exists('_3244b8b7599d3eb98cb9b26ff1ec31be')) { $__blaze->compile('/home3/myrwqtei/AbinotPeyvand/vendor/livewire/flux/src/../stubs/resources/views/flux/icon/eye-slash.blade.php', $__blaze->compiledPath.'/3244b8b7599d3eb98cb9b26ff1ec31be.php'); require $__blaze->compiledPath.'/3244b8b7599d3eb98cb9b26ff1ec31be.php'; } ?>
<?php $__blaze->pushData(['variant' => $iconVariant,'class' => 'hidden [[data-viewable-open]>&]:block']); ?>
<?php _3244b8b7599d3eb98cb9b26ff1ec31be($__blaze, ['variant' => $iconVariant,'class' => 'hidden [[data-viewable-open]>&]:block'], [], ['variant'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
    <?php if (!function_exists('_cea6a96b2bc6cab7cbe6198456ac6390')) { $__blaze->compile('/home3/myrwqtei/AbinotPeyvand/vendor/livewire/flux/src/../stubs/resources/views/flux/icon/eye.blade.php', $__blaze->compiledPath.'/cea6a96b2bc6cab7cbe6198456ac6390.php'); require $__blaze->compiledPath.'/cea6a96b2bc6cab7cbe6198456ac6390.php'; } ?>
<?php $__blaze->pushData(['variant' => $iconVariant,'class' => 'block [[data-viewable-open]>&]:hidden']); ?>
<?php _cea6a96b2bc6cab7cbe6198456ac6390($__blaze, ['variant' => $iconVariant,'class' => 'block [[data-viewable-open]>&]:hidden'], [], ['variant'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
<?php $__slots65233d9163ae832b5948df7c03dc9ee4['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots65233d9163ae832b5948df7c03dc9ee4); ?>
<?php _65233d9163ae832b5948df7c03dc9ee4($__blaze, $__attrs65233d9163ae832b5948df7c03dc9ee4, $__slots65233d9163ae832b5948df7c03dc9ee4, ['attributes', 'size'], ['xData' => 'x-data', 'xOn:click' => 'x-on:click', 'xBind:dataViewableOpen' => 'x-bind:data-viewable-open', 'ariaLabel' => 'aria-label'], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack65233d9163ae832b5948df7c03dc9ee4)) { $__slots65233d9163ae832b5948df7c03dc9ee4 = array_pop($__slotsStack65233d9163ae832b5948df7c03dc9ee4); } ?>
<?php if (! empty($__attrsStack65233d9163ae832b5948df7c03dc9ee4)) { $__attrs65233d9163ae832b5948df7c03dc9ee4 = array_pop($__attrsStack65233d9163ae832b5948df7c03dc9ee4); } ?>
<?php $__blaze->popData(); ?>
<?php
echo ltrim(ob_get_clean());
} endif; ?><?php /**PATH /home3/myrwqtei/AbinotPeyvand/vendor/livewire/flux/src/../stubs/resources/views/flux/input/viewable.blade.php ENDPATH**/ ?>