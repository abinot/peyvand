<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home3/myrwqtei/AbinotPeyvand/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/header.blade.php ENDPATH**/ ?>